// TypeScript bindings for emscripten-generated code.  Automatically generated at compile time.
declare namespace RuntimeExports {
    /**
     * @param {string|null=} returnType
     * @param {Array=} argTypes
     * @param {Arguments|Array=} args
     * @param {Object=} opts
     */
    function ccall(ident: any, returnType?: (string | null) | undefined, argTypes?: any[] | undefined, args?: (Arguments | any[]) | undefined, opts?: any | undefined): any;
    /**
     * @param {string=} returnType
     * @param {Array=} argTypes
     * @param {Object=} opts
     */
    function cwrap(ident: any, returnType?: string | undefined, argTypes?: any[] | undefined, opts?: any | undefined): any;
    namespace FS {
        export let root: any;
        export let mounts: any[];
        export let devices: {};
        export let streams: any[];
        export let nextInode: number;
        export let nameTable: any;
        export let currentPath: string;
        export let initialized: boolean;
        export let ignorePermissions: boolean;
        export let filesystems: any;
        export let syncFSRequests: number;
        export let readFiles: {};
        export { ErrnoError };
        export { FSStream };
        export { FSNode };
        export function lookupPath(path: any, opts?: {}): {
            path: string;
            node?: undefined;
        } | {
            path: string;
            node: any;
        };
        export function getPath(node: any): any;
        export function hashName(parentid: any, name: any): number;
        export function hashAddNode(node: any): void;
        export function hashRemoveNode(node: any): void;
        export function lookupNode(parent: any, name: any): any;
        export function createNode(parent: any, name: any, mode: any, rdev: any): any;
        export function destroyNode(node: any): void;
        export function isRoot(node: any): boolean;
        export function isMountpoint(node: any): boolean;
        export function isFile(mode: any): boolean;
        export function isDir(mode: any): boolean;
        export function isLink(mode: any): boolean;
        export function isChrdev(mode: any): boolean;
        export function isBlkdev(mode: any): boolean;
        export function isFIFO(mode: any): boolean;
        export function isSocket(mode: any): boolean;
        export function flagsToPermissionString(flag: any): string;
        export function nodePermissions(node: any, perms: any): 0 | 2;
        export function mayLookup(dir: any): any;
        export function mayCreate(dir: any, name: any): any;
        export function mayDelete(dir: any, name: any, isdir: any): any;
        export function mayOpen(node: any, flags: any): any;
        export function checkOpExists(op: any, err: any): any;
        export let MAX_OPEN_FDS: number;
        export function nextfd(): number;
        export function getStreamChecked(fd: any): any;
        export function getStream(fd: any): any;
        export function createStream(stream: any, fd?: number): any;
        export function closeStream(fd: any): void;
        export function dupStream(origStream: any, fd?: number): any;
        export function doSetAttr(stream: any, node: any, attr: any): void;
        export namespace chrdev_stream_ops {
            function open(stream: any): void;
            function llseek(): never;
        }
        export function major(dev: any): number;
        export function minor(dev: any): number;
        export function makedev(ma: any, mi: any): number;
        export function registerDevice(dev: any, ops: any): void;
        export function getDevice(dev: any): any;
        export function getMounts(mount: any): any[];
        export function syncfs(populate: any, callback: any): void;
        export function mount(type: any, opts: any, mountpoint: any): any;
        export function unmount(mountpoint: any): void;
        export function lookup(parent: any, name: any): any;
        export function mknod(path: any, mode: any, dev: any): any;
        export function statfs(path: any): any;
        export function statfsStream(stream: any): any;
        export function statfsNode(node: any): {
            bsize: number;
            frsize: number;
            blocks: number;
            bfree: number;
            bavail: number;
            files: any;
            ffree: number;
            fsid: number;
            flags: number;
            namelen: number;
        };
        export function create(path: any, mode?: number): any;
        export function mkdir(path: any, mode?: number): any;
        export function mkdirTree(path: any, mode: any): void;
        export function mkdev(path: any, mode: any, dev: any): any;
        export function symlink(oldpath: any, newpath: any): any;
        export function rename(old_path: any, new_path: any): void;
        export function rmdir(path: any): void;
        export function readdir(path: any): any;
        export function unlink(path: any): void;
        export function readlink(path: any): any;
        export function stat(path: any, dontFollow: any): any;
        export function fstat(fd: any): any;
        export function lstat(path: any): any;
        export function doChmod(stream: any, node: any, mode: any, dontFollow: any): void;
        export function chmod(path: any, mode: any, dontFollow: any): void;
        export function lchmod(path: any, mode: any): void;
        export function fchmod(fd: any, mode: any): void;
        export function doChown(stream: any, node: any, dontFollow: any): void;
        export function chown(path: any, uid: any, gid: any, dontFollow: any): void;
        export function lchown(path: any, uid: any, gid: any): void;
        export function fchown(fd: any, uid: any, gid: any): void;
        export function doTruncate(stream: any, node: any, len: any): void;
        export function truncate(path: any, len: any): void;
        export function ftruncate(fd: any, len: any): void;
        export function utime(path: any, atime: any, mtime: any): void;
        export function open(path: any, flags: any, mode?: number): any;
        export function close(stream: any): void;
        export function isClosed(stream: any): boolean;
        export function llseek(stream: any, offset: any, whence: any): any;
        export function read(stream: any, buffer: any, offset: any, length: any, position: any): any;
        export function write(stream: any, buffer: any, offset: any, length: any, position: any, canOwn: any): any;
        export function mmap(stream: any, length: any, position: any, prot: any, flags: any): any;
        export function msync(stream: any, buffer: any, offset: any, length: any, mmapFlags: any): any;
        export function ioctl(stream: any, cmd: any, arg: any): any;
        export function readFile(path: any, opts?: {}): Uint8Array<any>;
        export function writeFile(path: any, data: any, opts?: {}): void;
        export function cwd(): any;
        export function chdir(path: any): void;
        export function createDefaultDirectories(): void;
        export function createDefaultDevices(): void;
        export function createSpecialDirectories(): void;
        export function createStandardStreams(input: any, output: any, error: any): void;
        export function staticInit(): void;
        export function init(input: any, output: any, error: any): void;
        export function quit(): void;
        export function findObject(path: any, dontResolveLastLink: any): any;
        export function analyzePath(path: any, dontResolveLastLink: any): {
            isRoot: boolean;
            exists: boolean;
            error: number;
            name: any;
            path: any;
            object: any;
            parentExists: boolean;
            parentPath: any;
            parentObject: any;
        };
        export function createPath(parent: any, path: any, canRead: any, canWrite: any): any;
        export function createFile(parent: any, name: any, properties: any, canRead: any, canWrite: any): any;
        export function createDataFile(parent: any, name: any, data: any, canRead: any, canWrite: any, canOwn: any): void;
        export function createDevice(parent: any, name: any, input: any, output: any): any;
        export function forceLoadFile(obj: any): boolean;
        export function createLazyFile(parent: any, name: any, url: any, canRead: any, canWrite: any): any;
    }
    namespace MEMFS {
        let ops_table: any;
        function mount(mount: any): any;
        function createNode(parent: any, name: any, mode: any, dev: any): any;
        function getFileDataAsTypedArray(node: any): any;
        function expandFileStorage(node: any, newCapacity: any): void;
        function resizeFileStorage(node: any, newSize: any): void;
        namespace node_ops {
            function getattr(node: any): {
                dev: any;
                ino: any;
                mode: any;
                nlink: number;
                uid: number;
                gid: number;
                rdev: any;
                size: any;
                atime: Date;
                mtime: Date;
                ctime: Date;
                blksize: number;
                blocks: number;
            };
            function setattr(node: any, attr: any): void;
            function lookup(parent: any, name: any): never;
            function mknod(parent: any, name: any, mode: any, dev: any): any;
            function rename(old_node: any, new_dir: any, new_name: any): void;
            function unlink(parent: any, name: any): void;
            function rmdir(parent: any, name: any): void;
            function readdir(node: any): string[];
            function symlink(parent: any, newname: any, oldpath: any): any;
            function readlink(node: any): any;
        }
        namespace stream_ops {
            function read(stream: any, buffer: any, offset: any, length: any, position: any): number;
            function write(stream: any, buffer: any, offset: any, length: any, position: any, canOwn: any): any;
            function llseek(stream: any, offset: any, whence: any): any;
            function mmap(stream: any, length: any, position: any, prot: any, flags: any): {
                ptr: any;
                allocated: boolean;
            };
            function msync(stream: any, buffer: any, offset: any, length: any, mmapFlags: any): number;
        }
    }
    function FS_createPath(...args: any[]): any;
    function FS_createDataFile(...args: any[]): any;
    function FS_createPreloadedFile(parent: any, name: any, url: any, canRead: any, canWrite: any, onload: any, onerror: any, dontCreateFile: any, canOwn: any, preFinish: any): void;
    function FS_unlink(...args: any[]): any;
    function FS_createLazyFile(...args: any[]): any;
    function FS_createDevice(...args: any[]): any;
    let addRunDependency: any;
    let removeRunDependency: any;
}
declare class ErrnoError {
    constructor(errno: any);
    name: string;
    errno: any;
}
declare class FSStream {
    shared: {};
    set object(val: any);
    get object(): any;
    node: any;
    get isRead(): boolean;
    get isWrite(): boolean;
    get isAppend(): number;
    set flags(val: any);
    get flags(): any;
    set position(val: any);
    get position(): any;
}
declare class FSNode {
    constructor(parent: any, name: any, mode: any, rdev: any);
    node_ops: {};
    stream_ops: {};
    readMode: number;
    writeMode: number;
    mounted: any;
    parent: any;
    mount: any;
    id: number;
    name: any;
    mode: any;
    rdev: any;
    atime: number;
    mtime: number;
    ctime: number;
    set read(val: boolean);
    get read(): boolean;
    set write(val: boolean);
    get write(): boolean;
    get isFolder(): any;
    get isDevice(): any;
}
interface WasmModule {
}

type EmbindString = ArrayBuffer|Uint8Array|Uint8ClampedArray|Int8Array|string;
export interface ClassHandle {
  isAliasOf(other: ClassHandle): boolean;
  delete(): void;
  deleteLater(): this;
  isDeleted(): boolean;
  // @ts-ignore - If targeting lower than ESNext, this symbol might not exist.
  [Symbol.dispose](): void;
  clone(): this;
}
export interface mjrIndexTypeValue<T extends number> {
  value: T;
}
export type mjrIndexType = mjrIndexTypeValue<0>|mjrIndexTypeValue<1>;

export interface mjrMeshPrimitiveTypeValue<T extends number> {
  value: T;
}
export type mjrMeshPrimitiveType = mjrMeshPrimitiveTypeValue<0>|mjrMeshPrimitiveTypeValue<1>;

export interface mjrPixelFormatValue<T extends number> {
  value: T;
}
export type mjrPixelFormat = mjrPixelFormatValue<0>|mjrPixelFormatValue<1>|mjrPixelFormatValue<2>|mjrPixelFormatValue<3>|mjrPixelFormatValue<4>|mjrPixelFormatValue<5>|mjrPixelFormatValue<6>;

export interface mjrVertexAttributeTypeValue<T extends number> {
  value: T;
}
export type mjrVertexAttributeType = mjrVertexAttributeTypeValue<0>|mjrVertexAttributeTypeValue<1>|mjrVertexAttributeTypeValue<2>|mjrVertexAttributeTypeValue<3>;

export interface mjrVertexAttributeUsageValue<T extends number> {
  value: T;
}
export type mjrVertexAttributeUsage = mjrVertexAttributeUsageValue<0>|mjrVertexAttributeUsageValue<1>|mjrVertexAttributeUsageValue<2>|mjrVertexAttributeUsageValue<3>|mjrVertexAttributeUsageValue<4>;

export interface mjtAlignFreeValue<T extends number> {
  value: T;
}
export type mjtAlignFree = mjtAlignFreeValue<0>|mjtAlignFreeValue<1>|mjtAlignFreeValue<2>;

export interface mjtBiasValue<T extends number> {
  value: T;
}
export type mjtBias = mjtBiasValue<0>|mjtBiasValue<1>|mjtBiasValue<2>|mjtBiasValue<3>|mjtBiasValue<4>|mjtBiasValue<5>;

export interface mjtBuiltinValue<T extends number> {
  value: T;
}
export type mjtBuiltin = mjtBuiltinValue<0>|mjtBuiltinValue<1>|mjtBuiltinValue<2>|mjtBuiltinValue<3>;

export interface mjtButtonValue<T extends number> {
  value: T;
}
export type mjtButton = mjtButtonValue<0>|mjtButtonValue<1>|mjtButtonValue<2>|mjtButtonValue<3>;

export interface mjtCTimerValue<T extends number> {
  value: T;
}
export type mjtCTimer = mjtCTimerValue<0>|mjtCTimerValue<1>|mjtCTimerValue<2>|mjtCTimerValue<3>|mjtCTimerValue<4>|mjtCTimerValue<5>|mjtCTimerValue<6>|mjtCTimerValue<7>|mjtCTimerValue<8>|mjtCTimerValue<9>;

export interface mjtCamLightValue<T extends number> {
  value: T;
}
export type mjtCamLight = mjtCamLightValue<0>|mjtCamLightValue<1>|mjtCamLightValue<2>|mjtCamLightValue<3>|mjtCamLightValue<4>;

export interface mjtCamOutBitValue<T extends number> {
  value: T;
}
export type mjtCamOutBit = mjtCamOutBitValue<1>|mjtCamOutBitValue<2>|mjtCamOutBitValue<4>|mjtCamOutBitValue<8>|mjtCamOutBitValue<16>|mjtCamOutBitValue<5>;

export interface mjtCameraValue<T extends number> {
  value: T;
}
export type mjtCamera = mjtCameraValue<0>|mjtCameraValue<1>|mjtCameraValue<2>|mjtCameraValue<3>;

export interface mjtCatBitValue<T extends number> {
  value: T;
}
export type mjtCatBit = mjtCatBitValue<1>|mjtCatBitValue<2>|mjtCatBitValue<4>|mjtCatBitValue<7>;

export interface mjtColorSpaceValue<T extends number> {
  value: T;
}
export type mjtColorSpace = mjtColorSpaceValue<0>|mjtColorSpaceValue<1>|mjtColorSpaceValue<2>;

export interface mjtConDataFieldValue<T extends number> {
  value: T;
}
export type mjtConDataField = mjtConDataFieldValue<0>|mjtConDataFieldValue<1>|mjtConDataFieldValue<2>|mjtConDataFieldValue<3>|mjtConDataFieldValue<4>|mjtConDataFieldValue<5>|mjtConDataFieldValue<6>|mjtConDataFieldValue<7>;

export interface mjtConeValue<T extends number> {
  value: T;
}
export type mjtCone = mjtConeValue<0>|mjtConeValue<1>;

export interface mjtConflictValue<T extends number> {
  value: T;
}
export type mjtConflict = mjtConflictValue<0>|mjtConflictValue<1>|mjtConflictValue<2>;

export interface mjtConstraintValue<T extends number> {
  value: T;
}
export type mjtConstraint = mjtConstraintValue<0>|mjtConstraintValue<1>|mjtConstraintValue<2>|mjtConstraintValue<3>|mjtConstraintValue<4>|mjtConstraintValue<5>|mjtConstraintValue<6>|mjtConstraintValue<7>;

export interface mjtConstraintStateValue<T extends number> {
  value: T;
}
export type mjtConstraintState = mjtConstraintStateValue<0>|mjtConstraintStateValue<1>|mjtConstraintStateValue<2>|mjtConstraintStateValue<3>|mjtConstraintStateValue<4>;

export interface mjtCtrlChartValue<T extends number> {
  value: T;
}
export type mjtCtrlChart = mjtCtrlChartValue<1>|mjtCtrlChartValue<2>;

export interface mjtCtrlInputValue<T extends number> {
  value: T;
}
export type mjtCtrlInput = mjtCtrlInputValue<1>|mjtCtrlInputValue<2>|mjtCtrlInputValue<4>|mjtCtrlInputValue<8>|mjtCtrlInputValue<16>;

export interface mjtDataTypeValue<T extends number> {
  value: T;
}
export type mjtDataType = mjtDataTypeValue<0>|mjtDataTypeValue<1>|mjtDataTypeValue<2>|mjtDataTypeValue<3>;

export interface mjtDepthMapValue<T extends number> {
  value: T;
}
export type mjtDepthMap = mjtDepthMapValue<0>|mjtDepthMapValue<1>;

export interface mjtDisableBitValue<T extends number> {
  value: T;
}
export type mjtDisableBit = mjtDisableBitValue<1>|mjtDisableBitValue<2>|mjtDisableBitValue<4>|mjtDisableBitValue<8>|mjtDisableBitValue<16>|mjtDisableBitValue<32>|mjtDisableBitValue<64>|mjtDisableBitValue<128>|mjtDisableBitValue<256>|mjtDisableBitValue<512>|mjtDisableBitValue<1024>|mjtDisableBitValue<2048>|mjtDisableBitValue<4096>|mjtDisableBitValue<8192>|mjtDisableBitValue<16384>|mjtDisableBitValue<32768>|mjtDisableBitValue<65536>|mjtDisableBitValue<131072>|mjtDisableBitValue<262144>|mjtDisableBitValue<524288>|mjtDisableBitValue<20>;

export interface mjtDynValue<T extends number> {
  value: T;
}
export type mjtDyn = mjtDynValue<0>|mjtDynValue<1>|mjtDynValue<2>|mjtDynValue<3>|mjtDynValue<4>|mjtDynValue<5>|mjtDynValue<6>|mjtDynValue<7>;

export interface mjtEnableBitValue<T extends number> {
  value: T;
}
export type mjtEnableBit = mjtEnableBitValue<1>|mjtEnableBitValue<2>|mjtEnableBitValue<4>|mjtEnableBitValue<8>|mjtEnableBitValue<16>|mjtEnableBitValue<32>|mjtEnableBitValue<6>;

export interface mjtEqValue<T extends number> {
  value: T;
}
export type mjtEq = mjtEqValue<0>|mjtEqValue<1>|mjtEqValue<2>|mjtEqValue<3>|mjtEqValue<4>|mjtEqValue<5>|mjtEqValue<6>|mjtEqValue<7>;

export interface mjtEventValue<T extends number> {
  value: T;
}
export type mjtEvent = mjtEventValue<0>|mjtEventValue<1>|mjtEventValue<2>|mjtEventValue<3>|mjtEventValue<4>|mjtEventValue<5>|mjtEventValue<6>|mjtEventValue<7>|mjtEventValue<8>;

export interface mjtFlexSelfValue<T extends number> {
  value: T;
}
export type mjtFlexSelf = mjtFlexSelfValue<0>|mjtFlexSelfValue<1>|mjtFlexSelfValue<2>|mjtFlexSelfValue<3>|mjtFlexSelfValue<4>;

export interface mjtFontValue<T extends number> {
  value: T;
}
export type mjtFont = mjtFontValue<0>|mjtFontValue<1>|mjtFontValue<2>;

export interface mjtFontScaleValue<T extends number> {
  value: T;
}
export type mjtFontScale = mjtFontScaleValue<50>|mjtFontScaleValue<100>|mjtFontScaleValue<150>|mjtFontScaleValue<200>|mjtFontScaleValue<250>|mjtFontScaleValue<300>;

export interface mjtFrameValue<T extends number> {
  value: T;
}
export type mjtFrame = mjtFrameValue<0>|mjtFrameValue<1>|mjtFrameValue<2>|mjtFrameValue<3>|mjtFrameValue<4>|mjtFrameValue<5>|mjtFrameValue<6>|mjtFrameValue<7>|mjtFrameValue<8>;

export interface mjtFramebufferValue<T extends number> {
  value: T;
}
export type mjtFramebuffer = mjtFramebufferValue<0>|mjtFramebufferValue<1>;

export interface mjtGainValue<T extends number> {
  value: T;
}
export type mjtGain = mjtGainValue<0>|mjtGainValue<1>|mjtGainValue<2>|mjtGainValue<3>|mjtGainValue<4>|mjtGainValue<5>|mjtGainValue<6>;

export interface mjtGeomValue<T extends number> {
  value: T;
}
export type mjtGeom = mjtGeomValue<0>|mjtGeomValue<1>|mjtGeomValue<2>|mjtGeomValue<3>|mjtGeomValue<4>|mjtGeomValue<5>|mjtGeomValue<6>|mjtGeomValue<7>|mjtGeomValue<8>|mjtGeomValue<9>|mjtGeomValue<100>|mjtGeomValue<101>|mjtGeomValue<102>|mjtGeomValue<103>|mjtGeomValue<104>|mjtGeomValue<105>|mjtGeomValue<106>|mjtGeomValue<107>|mjtGeomValue<108>|mjtGeomValue<1001>;

export interface mjtGeomInertiaValue<T extends number> {
  value: T;
}
export type mjtGeomInertia = mjtGeomInertiaValue<0>|mjtGeomInertiaValue<1>;

export interface mjtGridPosValue<T extends number> {
  value: T;
}
export type mjtGridPos = mjtGridPosValue<0>|mjtGridPosValue<1>|mjtGridPosValue<2>|mjtGridPosValue<3>|mjtGridPosValue<4>|mjtGridPosValue<5>|mjtGridPosValue<6>|mjtGridPosValue<7>;

export interface mjtInertiaFromGeomValue<T extends number> {
  value: T;
}
export type mjtInertiaFromGeom = mjtInertiaFromGeomValue<0>|mjtInertiaFromGeomValue<1>|mjtInertiaFromGeomValue<2>;

export interface mjtIntegratorValue<T extends number> {
  value: T;
}
export type mjtIntegrator = mjtIntegratorValue<0>|mjtIntegratorValue<1>|mjtIntegratorValue<2>|mjtIntegratorValue<3>;

export interface mjtItemValue<T extends number> {
  value: T;
}
export type mjtItem = mjtItemValue<-2>|mjtItemValue<-1>|mjtItemValue<0>|mjtItemValue<1>|mjtItemValue<2>|mjtItemValue<3>|mjtItemValue<4>|mjtItemValue<5>|mjtItemValue<6>|mjtItemValue<7>|mjtItemValue<8>|mjtItemValue<9>|mjtItemValue<10>|mjtItemValue<11>|mjtItemValue<12>|mjtItemValue<13>|mjtItemValue<14>;

export interface mjtJacobianValue<T extends number> {
  value: T;
}
export type mjtJacobian = mjtJacobianValue<0>|mjtJacobianValue<1>|mjtJacobianValue<2>;

export interface mjtJointValue<T extends number> {
  value: T;
}
export type mjtJoint = mjtJointValue<0>|mjtJointValue<1>|mjtJointValue<2>|mjtJointValue<3>;

export interface mjtLRModeValue<T extends number> {
  value: T;
}
export type mjtLRMode = mjtLRModeValue<0>|mjtLRModeValue<1>|mjtLRModeValue<2>|mjtLRModeValue<3>;

export interface mjtLabelValue<T extends number> {
  value: T;
}
export type mjtLabel = mjtLabelValue<0>|mjtLabelValue<1>|mjtLabelValue<2>|mjtLabelValue<3>|mjtLabelValue<4>|mjtLabelValue<5>|mjtLabelValue<6>|mjtLabelValue<7>|mjtLabelValue<8>|mjtLabelValue<9>|mjtLabelValue<10>|mjtLabelValue<11>|mjtLabelValue<12>|mjtLabelValue<13>|mjtLabelValue<14>|mjtLabelValue<15>|mjtLabelValue<16>|mjtLabelValue<17>;

export interface mjtLightTypeValue<T extends number> {
  value: T;
}
export type mjtLightType = mjtLightTypeValue<0>|mjtLightTypeValue<1>|mjtLightTypeValue<2>|mjtLightTypeValue<3>;

export interface mjtLimitedValue<T extends number> {
  value: T;
}
export type mjtLimited = mjtLimitedValue<0>|mjtLimitedValue<1>|mjtLimitedValue<2>;

export interface mjtLogLevelValue<T extends number> {
  value: T;
}
export type mjtLogLevel = mjtLogLevelValue<0>|mjtLogLevelValue<1>|mjtLogLevelValue<2>|mjtLogLevelValue<3>;

export interface mjtLogTopicValue<T extends number> {
  value: T;
}
export type mjtLogTopic = mjtLogTopicValue<0>|mjtLogTopicValue<1>|mjtLogTopicValue<2>|mjtLogTopicValue<3>|mjtLogTopicValue<3>;

export interface mjtMarkValue<T extends number> {
  value: T;
}
export type mjtMark = mjtMarkValue<0>|mjtMarkValue<1>|mjtMarkValue<2>|mjtMarkValue<3>;

export interface mjtMeshBuiltinValue<T extends number> {
  value: T;
}
export type mjtMeshBuiltin = mjtMeshBuiltinValue<0>|mjtMeshBuiltinValue<1>|mjtMeshBuiltinValue<2>|mjtMeshBuiltinValue<3>|mjtMeshBuiltinValue<4>|mjtMeshBuiltinValue<5>|mjtMeshBuiltinValue<6>|mjtMeshBuiltinValue<7>;

export interface mjtMeshInertiaValue<T extends number> {
  value: T;
}
export type mjtMeshInertia = mjtMeshInertiaValue<0>|mjtMeshInertiaValue<1>|mjtMeshInertiaValue<2>|mjtMeshInertiaValue<3>;

export interface mjtMouseValue<T extends number> {
  value: T;
}
export type mjtMouse = mjtMouseValue<0>|mjtMouseValue<1>|mjtMouseValue<2>|mjtMouseValue<3>|mjtMouseValue<4>|mjtMouseValue<5>|mjtMouseValue<6>|mjtMouseValue<7>|mjtMouseValue<8>|mjtMouseValue<9>;

export interface mjtObjValue<T extends number> {
  value: T;
}
export type mjtObj = mjtObjValue<0>|mjtObjValue<1>|mjtObjValue<2>|mjtObjValue<3>|mjtObjValue<4>|mjtObjValue<5>|mjtObjValue<6>|mjtObjValue<7>|mjtObjValue<8>|mjtObjValue<9>|mjtObjValue<10>|mjtObjValue<11>|mjtObjValue<12>|mjtObjValue<13>|mjtObjValue<14>|mjtObjValue<15>|mjtObjValue<16>|mjtObjValue<17>|mjtObjValue<18>|mjtObjValue<19>|mjtObjValue<20>|mjtObjValue<21>|mjtObjValue<22>|mjtObjValue<23>|mjtObjValue<24>|mjtObjValue<25>|mjtObjValue<26>|mjtObjValue<100>|mjtObjValue<101>|mjtObjValue<102>;

export interface mjtOrientationValue<T extends number> {
  value: T;
}
export type mjtOrientation = mjtOrientationValue<0>|mjtOrientationValue<1>|mjtOrientationValue<2>|mjtOrientationValue<3>|mjtOrientationValue<4>;

export interface mjtPertBitValue<T extends number> {
  value: T;
}
export type mjtPertBit = mjtPertBitValue<1>|mjtPertBitValue<2>;

export interface mjtPluginCapabilityBitValue<T extends number> {
  value: T;
}
export type mjtPluginCapabilityBit = mjtPluginCapabilityBitValue<1>|mjtPluginCapabilityBitValue<2>|mjtPluginCapabilityBitValue<4>|mjtPluginCapabilityBitValue<8>;

export interface mjtProjectionValue<T extends number> {
  value: T;
}
export type mjtProjection = mjtProjectionValue<0>|mjtProjectionValue<1>;

export interface mjtRayDataFieldValue<T extends number> {
  value: T;
}
export type mjtRayDataField = mjtRayDataFieldValue<0>|mjtRayDataFieldValue<1>|mjtRayDataFieldValue<2>|mjtRayDataFieldValue<3>|mjtRayDataFieldValue<4>|mjtRayDataFieldValue<5>|mjtRayDataFieldValue<6>;

export interface mjtRndFlagValue<T extends number> {
  value: T;
}
export type mjtRndFlag = mjtRndFlagValue<0>|mjtRndFlagValue<1>|mjtRndFlagValue<2>|mjtRndFlagValue<3>|mjtRndFlagValue<4>|mjtRndFlagValue<5>|mjtRndFlagValue<6>|mjtRndFlagValue<7>|mjtRndFlagValue<8>|mjtRndFlagValue<9>|mjtRndFlagValue<10>|mjtRndFlagValue<11>;

export interface mjtSDFTypeValue<T extends number> {
  value: T;
}
export type mjtSDFType = mjtSDFTypeValue<0>|mjtSDFTypeValue<1>|mjtSDFTypeValue<2>|mjtSDFTypeValue<3>;

export interface mjtSameFrameValue<T extends number> {
  value: T;
}
export type mjtSameFrame = mjtSameFrameValue<0>|mjtSameFrameValue<1>|mjtSameFrameValue<2>|mjtSameFrameValue<3>|mjtSameFrameValue<4>;

export interface mjtSectionValue<T extends number> {
  value: T;
}
export type mjtSection = mjtSectionValue<0>|mjtSectionValue<1>|mjtSectionValue<2>;

export interface mjtSensorValue<T extends number> {
  value: T;
}
export type mjtSensor = mjtSensorValue<0>|mjtSensorValue<1>|mjtSensorValue<2>|mjtSensorValue<3>|mjtSensorValue<4>|mjtSensorValue<5>|mjtSensorValue<6>|mjtSensorValue<7>|mjtSensorValue<8>|mjtSensorValue<9>|mjtSensorValue<10>|mjtSensorValue<11>|mjtSensorValue<12>|mjtSensorValue<13>|mjtSensorValue<14>|mjtSensorValue<15>|mjtSensorValue<16>|mjtSensorValue<17>|mjtSensorValue<18>|mjtSensorValue<19>|mjtSensorValue<20>|mjtSensorValue<21>|mjtSensorValue<22>|mjtSensorValue<23>|mjtSensorValue<24>|mjtSensorValue<25>|mjtSensorValue<26>|mjtSensorValue<27>|mjtSensorValue<28>|mjtSensorValue<29>|mjtSensorValue<30>|mjtSensorValue<31>|mjtSensorValue<32>|mjtSensorValue<33>|mjtSensorValue<34>|mjtSensorValue<35>|mjtSensorValue<36>|mjtSensorValue<37>|mjtSensorValue<38>|mjtSensorValue<39>|mjtSensorValue<40>|mjtSensorValue<41>|mjtSensorValue<42>|mjtSensorValue<43>|mjtSensorValue<44>|mjtSensorValue<45>|mjtSensorValue<46>|mjtSensorValue<47>|mjtSensorValue<48>;

export interface mjtSleepPolicyValue<T extends number> {
  value: T;
}
export type mjtSleepPolicy = mjtSleepPolicyValue<0>|mjtSleepPolicyValue<1>|mjtSleepPolicyValue<2>|mjtSleepPolicyValue<3>|mjtSleepPolicyValue<4>|mjtSleepPolicyValue<5>;

export interface mjtSleepStateValue<T extends number> {
  value: T;
}
export type mjtSleepState = mjtSleepStateValue<-1>|mjtSleepStateValue<0>|mjtSleepStateValue<1>;

export interface mjtSolverValue<T extends number> {
  value: T;
}
export type mjtSolver = mjtSolverValue<0>|mjtSolverValue<1>|mjtSolverValue<2>;

export interface mjtStageValue<T extends number> {
  value: T;
}
export type mjtStage = mjtStageValue<0>|mjtStageValue<1>|mjtStageValue<2>|mjtStageValue<3>;

export interface mjtStateValue<T extends number> {
  value: T;
}
export type mjtState = mjtStateValue<1>|mjtStateValue<2>|mjtStateValue<4>|mjtStateValue<8>|mjtStateValue<16>|mjtStateValue<32>|mjtStateValue<64>|mjtStateValue<128>|mjtStateValue<256>|mjtStateValue<512>|mjtStateValue<1024>|mjtStateValue<2048>|mjtStateValue<4096>|mjtStateValue<8192>|mjtStateValue<14>|mjtStateValue<30>|mjtStateValue<8223>|mjtStateValue<8128>|mjtStateValue<16383>;

export interface mjtStereoValue<T extends number> {
  value: T;
}
export type mjtStereo = mjtStereoValue<0>|mjtStereoValue<1>|mjtStereoValue<2>;

export interface mjtTextureValue<T extends number> {
  value: T;
}
export type mjtTexture = mjtTextureValue<0>|mjtTextureValue<1>|mjtTextureValue<2>;

export interface mjtTextureRoleValue<T extends number> {
  value: T;
}
export type mjtTextureRole = mjtTextureRoleValue<0>|mjtTextureRoleValue<1>|mjtTextureRoleValue<2>|mjtTextureRoleValue<3>|mjtTextureRoleValue<4>|mjtTextureRoleValue<5>|mjtTextureRoleValue<6>|mjtTextureRoleValue<7>|mjtTextureRoleValue<8>|mjtTextureRoleValue<9>|mjtTextureRoleValue<10>;

export interface mjtTimerValue<T extends number> {
  value: T;
}
export type mjtTimer = mjtTimerValue<0>|mjtTimerValue<1>|mjtTimerValue<2>|mjtTimerValue<3>|mjtTimerValue<4>|mjtTimerValue<5>|mjtTimerValue<6>|mjtTimerValue<7>|mjtTimerValue<8>|mjtTimerValue<9>|mjtTimerValue<10>|mjtTimerValue<11>|mjtTimerValue<12>|mjtTimerValue<13>|mjtTimerValue<14>|mjtTimerValue<15>;

export interface mjtTrnValue<T extends number> {
  value: T;
}
export type mjtTrn = mjtTrnValue<0>|mjtTrnValue<1>|mjtTrnValue<2>|mjtTrnValue<3>|mjtTrnValue<4>|mjtTrnValue<5>|mjtTrnValue<6>|mjtTrnValue<1000>;

export interface mjtVisFlagValue<T extends number> {
  value: T;
}
export type mjtVisFlag = mjtVisFlagValue<0>|mjtVisFlagValue<1>|mjtVisFlagValue<2>|mjtVisFlagValue<3>|mjtVisFlagValue<4>|mjtVisFlagValue<5>|mjtVisFlagValue<6>|mjtVisFlagValue<7>|mjtVisFlagValue<8>|mjtVisFlagValue<9>|mjtVisFlagValue<10>|mjtVisFlagValue<11>|mjtVisFlagValue<12>|mjtVisFlagValue<13>|mjtVisFlagValue<14>|mjtVisFlagValue<15>|mjtVisFlagValue<16>|mjtVisFlagValue<17>|mjtVisFlagValue<18>|mjtVisFlagValue<19>|mjtVisFlagValue<20>|mjtVisFlagValue<21>|mjtVisFlagValue<22>|mjtVisFlagValue<23>|mjtVisFlagValue<24>|mjtVisFlagValue<25>|mjtVisFlagValue<26>|mjtVisFlagValue<27>|mjtVisFlagValue<28>|mjtVisFlagValue<29>|mjtVisFlagValue<30>|mjtVisFlagValue<31>;

export interface mjtWarningValue<T extends number> {
  value: T;
}
export type mjtWarning = mjtWarningValue<0>|mjtWarningValue<1>|mjtWarningValue<2>|mjtWarningValue<3>|mjtWarningValue<4>|mjtWarningValue<5>|mjtWarningValue<6>|mjtWarningValue<7>;

export interface mjtWrapValue<T extends number> {
  value: T;
}
export type mjtWrap = mjtWrapValue<0>|mjtWrapValue<1>|mjtWrapValue<2>|mjtWrapValue<3>|mjtWrapValue<4>|mjtWrapValue<5>;

export interface MjModelActuatorAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  trntype: any;
  dyntype: any;
  gaintype: any;
  biastype: any;
  trnid: any;
  actadr: any;
  actnum: any;
  group: any;
  ctrllimited: any;
  forcelimited: any;
  actlimited: any;
  dynprm: any;
  gainprm: any;
  biasprm: any;
  ctrlrange: any;
  forcerange: any;
  actrange: any;
  gear: any;
  cranklength: any;
  acc0: any;
  length0: any;
  lengthrange: any;
  user: any;
}

export interface MjModelBodyAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  parentid: any;
  rootid: any;
  weldid: any;
  mocapid: any;
  jntnum: any;
  jntadr: any;
  dofnum: any;
  dofadr: any;
  geomnum: any;
  geomadr: any;
  simple: any;
  sameframe: any;
  pos: any;
  quat: any;
  ipos: any;
  iquat: any;
  mass: any;
  subtreemass: any;
  inertia: any;
  invweight0: any;
  user: any;
}

export interface MjModelCameraAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  mode: any;
  bodyid: any;
  targetbodyid: any;
  pos: any;
  quat: any;
  poscom0: any;
  pos0: any;
  mat0: any;
  fovy: any;
  ipd: any;
  user: any;
}

export interface MjModelEqualityAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  type: any;
  obj1id: any;
  obj2id: any;
  active0: any;
  solref: any;
  solimp: any;
  data: any;
}

export interface MjModelExcludeAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  signature: any;
}

export interface MjModelGeomAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  type: any;
  contype: any;
  conaffinity: any;
  condim: any;
  bodyid: any;
  dataid: any;
  matid: any;
  group: any;
  priority: any;
  sameframe: any;
  solmix: any;
  solref: any;
  solimp: any;
  size: any;
  rbound: any;
  pos: any;
  quat: any;
  friction: any;
  margin: any;
  gap: any;
  user: any;
  rgba: any;
}

export interface MjModelHfieldAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  size: any;
  nrow: any;
  ncol: any;
  adr: any;
  data: any;
}

export interface MjModelJointAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  qpos0: any;
  qpos_spring: any;
  type: any;
  qposadr: any;
  dofadr: any;
  group: any;
  limited: any;
  pos: any;
  axis: any;
  stiffness: any;
  stiffnesspoly: any;
  range: any;
  margin: any;
  user: any;
  bodyid: any;
  jntid: any;
  parentid: any;
  Madr: any;
  simplenum: any;
  solref: any;
  solimp: any;
  frictionloss: any;
  armature: any;
  damping: any;
  dampingpoly: any;
  invweight0: any;
  M0: any;
}

export interface MjModelLightAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  mode: any;
  bodyid: any;
  targetbodyid: any;
  type: any;
  castshadow: any;
  active: any;
  pos: any;
  dir: any;
  poscom0: any;
  pos0: any;
  dir0: any;
  attenuation: any;
  cutoff: any;
  exponent: any;
  ambient: any;
  diffuse: any;
  specular: any;
}

export interface MjModelMaterialAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  texid: any;
  texuniform: any;
  texrepeat: any;
  emission: any;
  specular: any;
  shininess: any;
  reflectance: any;
  rgba: any;
}

export interface MjModelMeshAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  vertadr: any;
  vertnum: any;
  texcoordadr: any;
  faceadr: any;
  facenum: any;
  graphadr: any;
}

export interface MjModelNumericAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  adr: any;
  size: any;
  data: any;
}

export interface MjModelPairAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  dim: any;
  geom1: any;
  geom2: any;
  signature: any;
  solref: any;
  solimp: any;
  margin: any;
  gap: any;
  friction: any;
}

export interface MjModelSensorAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  type: any;
  datatype: any;
  needstage: any;
  objtype: any;
  objid: any;
  reftype: any;
  refid: any;
  dim: any;
  adr: any;
  cutoff: any;
  noise: any;
  user: any;
}

export interface MjModelSiteAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  type: any;
  bodyid: any;
  matid: any;
  group: any;
  sameframe: any;
  size: any;
  pos: any;
  quat: any;
  user: any;
  rgba: any;
}

export interface MjModelSkinAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  matid: any;
  rgba: any;
  inflate: any;
  vertadr: any;
  vertnum: any;
  texcoordadr: any;
  faceadr: any;
  facenum: any;
  boneadr: any;
  bonenum: any;
}

export interface MjModelTendonAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  _adr: any;
  _num: any;
  _matid: any;
  _group: any;
  _limited: any;
  _width: any;
  _solref_lim: any;
  _solimp_lim: any;
  _solref_fri: any;
  _solimp_fri: any;
  _range: any;
  _margin: any;
  _stiffness: any;
  _stiffnesspoly: any;
  _damping: any;
  _dampingpoly: any;
  _frictionloss: any;
  _lengthspring: any;
  _length0: any;
  _invweight0: any;
  _user: any;
  _rgba: any;
  J_rownnz: any;
  J_rowadr: any;
  J_colind: any;
}

export interface MjModelTextureAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  type: any;
  height: any;
  width: any;
  nchannel: any;
  adr: any;
  data: any;
}

export interface MjModelTupleAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  adr: any;
  size: any;
  objtype: any;
  objid: any;
  objprm: any;
}

export interface MjModelKeyframeAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  time: any;
  qpos: any;
  qvel: any;
  act: any;
  mpos: any;
  mquat: any;
  ctrl: any;
}

export interface MjDataActuatorAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  ctrl: any;
  length: any;
  moment: any;
  velocity: any;
  force: any;
}

export interface MjDataBodyAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  xfrc_applied: any;
  xpos: any;
  xquat: any;
  xmat: any;
  xipos: any;
  ximat: any;
  subtree_com: any;
  cinert: any;
  crb: any;
  cvel: any;
  subtree_linvel: any;
  subtree_angmom: any;
  cacc: any;
  cfrc_int: any;
  cfrc_ext: any;
}

export interface MjDataCameraAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  xpos: any;
  xmat: any;
}

export interface MjDataGeomAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  xpos: any;
  xmat: any;
}

export interface MjDataJointAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  qpos: any;
  qvel: any;
  qacc_warmstart: any;
  qfrc_applied: any;
  qacc: any;
  xanchor: any;
  xaxis: any;
  cdof: any;
  qLDiagInv: any;
  cdof_dot: any;
  qfrc_bias: any;
  qfrc_passive: any;
  qfrc_actuator: any;
  qfrc_smooth: any;
  qacc_smooth: any;
  qfrc_constraint: any;
  qfrc_inverse: any;
}

export interface MjDataLightAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  xpos: any;
  xdir: any;
}

export interface MjDataSensorAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  data: any;
}

export interface MjDataSiteAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  xpos: any;
  xmat: any;
}

export interface MjDataTendonAccessor extends ClassHandle {
  readonly id: number;
  readonly name: string;
  wrapadr: any;
  wrapnum: any;
  length: any;
  velocity: any;
}

export interface MjContact extends ClassHandle {
  dim: number;
  efc_address: number;
  exclude: number;
  geom1: number;
  geom2: number;
  adhesion: number;
  dist: number;
  includemargin: number;
  mu: number;
  readonly H: any;
  readonly elem: any;
  readonly flex: any;
  readonly frame: any;
  readonly friction: any;
  readonly geom: any;
  readonly pos: any;
  readonly solimp: any;
  readonly solref: any;
  readonly solreffriction: any;
  readonly vert: any;
  copy(): MjContact;
}

export interface MjData extends ClassHandle {
  solver: MjSolverStatVec;
  timer: MjTimerStatVec;
  warning: MjWarningStatVec;
  readonly contact: MjContactVec;
  flg_energypos: boolean;
  flg_energyvel: boolean;
  flg_rnepost: boolean;
  flg_subtreevel: boolean;
  threadlock: boolean;
  efm_active: number;
  maxuse_arena: number;
  maxuse_con: number;
  maxuse_efc: number;
  maxuse_stack: number;
  nA: number;
  nJ: number;
  nY: number;
  narena: number;
  nbody_awake: number;
  nbuffer: number;
  ncon: number;
  ne: number;
  nefc: number;
  nefmK: number;
  nefmL: number;
  nefmdof: number;
  nf: number;
  nidof: number;
  nisland: number;
  nl: number;
  nparent_awake: number;
  nplugin: number;
  ntree_awake: number;
  nv_awake: number;
  parena: number;
  pbase: number;
  pstack: number;
  threadpool: number;
  signature: bigint;
  time: number;
  readonly M: any;
  readonly act: any;
  readonly act_dot: any;
  readonly actuator_force: any;
  readonly actuator_length: any;
  readonly actuator_moment: any;
  readonly actuator_velocity: any;
  readonly arena: any;
  readonly body_awake: any;
  readonly body_awake_ind: any;
  readonly buffer: any;
  readonly bvh_aabb_dyn: any;
  readonly bvh_active: any;
  readonly cacc: any;
  readonly cam_xmat: any;
  readonly cam_xpos: any;
  readonly cdof: any;
  readonly cdof_dot: any;
  readonly cfrc_ext: any;
  readonly cfrc_int: any;
  readonly cinert: any;
  readonly crb: any;
  readonly ctrl: any;
  readonly cvel: any;
  readonly dof_awake_ind: any;
  readonly dof_island: any;
  readonly efc_AR: any;
  readonly efc_AR_colind: any;
  readonly efc_AR_rowadr: any;
  readonly efc_AR_rownnz: any;
  readonly efc_D: any;
  readonly efc_J: any;
  readonly efc_J_colind: any;
  readonly efc_J_rowadr: any;
  readonly efc_J_rownnz: any;
  readonly efc_J_rowsuper: any;
  readonly efc_KBIP: any;
  readonly efc_R: any;
  readonly efc_Y: any;
  readonly efc_Y_colind: any;
  readonly efc_Y_rowadr: any;
  readonly efc_Y_rownnz: any;
  readonly efc_aref: any;
  readonly efc_b: any;
  readonly efc_diagA: any;
  readonly efc_force: any;
  readonly efc_frictionloss: any;
  readonly efc_id: any;
  readonly efc_island: any;
  readonly efc_margin: any;
  readonly efc_pos: any;
  readonly efc_state: any;
  readonly efc_type: any;
  readonly efc_vel: any;
  readonly efm_K_colind: any;
  readonly efm_K_rowadr: any;
  readonly efm_K_rownnz: any;
  readonly efm_K_val: any;
  readonly efm_L: any;
  readonly efm_c: any;
  readonly efm_dofid: any;
  readonly energy: any;
  readonly eq_active: any;
  readonly flexedge_J: any;
  readonly flexedge_length: any;
  readonly flexedge_velocity: any;
  readonly flexelem_aabb: any;
  readonly flexelem_krot: any;
  readonly flexvert_J: any;
  readonly flexvert_length: any;
  readonly flexvert_xpos: any;
  readonly geom_xmat: any;
  readonly geom_xpos: any;
  readonly history: any;
  readonly iacc: any;
  readonly iacc_smooth: any;
  readonly iefc_D: any;
  readonly iefc_R: any;
  readonly iefc_aref: any;
  readonly iefc_force: any;
  readonly iefc_frictionloss: any;
  readonly iefc_id: any;
  readonly iefc_state: any;
  readonly iefc_type: any;
  readonly ifrc_constraint: any;
  readonly ifrc_smooth: any;
  readonly island_dofadr: any;
  readonly island_idofadr: any;
  readonly island_iefcadr: any;
  readonly island_itreeadr: any;
  readonly island_ne: any;
  readonly island_nefc: any;
  readonly island_nf: any;
  readonly island_ntree: any;
  readonly island_nv: any;
  readonly light_xdir: any;
  readonly light_xpos: any;
  readonly map_dof2idof: any;
  readonly map_efc2iefc: any;
  readonly map_idof2dof: any;
  readonly map_iefc2efc: any;
  readonly map_itree2tree: any;
  readonly mocap_pos: any;
  readonly mocap_quat: any;
  readonly moment_colind: any;
  readonly moment_rowadr: any;
  readonly moment_rownnz: any;
  readonly parent_awake_ind: any;
  readonly plugin: any;
  readonly plugin_data: any;
  readonly plugin_state: any;
  readonly qDeriv: any;
  readonly qH: any;
  readonly qHDiagInv: any;
  readonly qLD: any;
  readonly qLDiagInv: any;
  readonly qLU: any;
  readonly qacc: any;
  readonly qacc_smooth: any;
  readonly qacc_warmstart: any;
  readonly qfrc_actuator: any;
  readonly qfrc_adhesion: any;
  readonly qfrc_applied: any;
  readonly qfrc_bias: any;
  readonly qfrc_constraint: any;
  readonly qfrc_damper: any;
  readonly qfrc_fluid: any;
  readonly qfrc_gravcomp: any;
  readonly qfrc_inverse: any;
  readonly qfrc_passive: any;
  readonly qfrc_smooth: any;
  readonly qfrc_spring: any;
  readonly qpos: any;
  readonly qvel: any;
  readonly sensordata: any;
  readonly site_xmat: any;
  readonly site_xpos: any;
  readonly solver_fwdinv: any;
  readonly solver_niter: any;
  readonly solver_nnz: any;
  readonly subtree_angmom: any;
  readonly subtree_com: any;
  readonly subtree_linvel: any;
  readonly ten_J: any;
  readonly ten_length: any;
  readonly ten_velocity: any;
  readonly ten_wrapadr: any;
  readonly ten_wrapnum: any;
  readonly tendon_efcadr: any;
  readonly tree_asleep: any;
  readonly tree_awake: any;
  readonly tree_island: any;
  readonly userdata: any;
  readonly wrap_obj: any;
  readonly wrap_xpos: any;
  readonly xanchor: any;
  readonly xaxis: any;
  readonly xfrc_applied: any;
  readonly ximat: any;
  readonly xipos: any;
  readonly xmat: any;
  readonly xpos: any;
  readonly xquat: any;
  actuator(_0: number|string): MjDataActuatorAccessor;
  body(_0: number|string): MjDataBodyAccessor;
  cam(_0: number|string): MjDataCameraAccessor;
  geom(_0: number|string): MjDataGeomAccessor;
  jnt(_0: number|string): MjDataJointAccessor;
  light(_0: number|string): MjDataLightAccessor;
  sensor(_0: number|string): MjDataSensorAccessor;
  site(_0: number|string): MjDataSiteAccessor;
  tendon(_0: number|string): MjDataTendonAccessor;
}

export interface MjLROpt extends ClassHandle {
  mode: number;
  useexisting: number;
  uselimit: number;
  accel: number;
  interval: number;
  inttotal: number;
  maxforce: number;
  timeconst: number;
  timestep: number;
  tolrange: number;
  copy(): MjLROpt;
}

export interface MjLogConfig extends ClassHandle {
  logto_console: boolean;
  logto_file: boolean;
  topics: number;
  readonly logfile: any;
  copy(): MjLogConfig;
}

export interface MjLogMessage extends ClassHandle {
  timestamp: boolean;
  level: number;
  line: number;
  topic: number;
  readonly body: string;
  readonly file: string;
  readonly func: string;
  readonly subject: any;
}

export interface MjModel extends ClassHandle {
  opt: MjOption;
  stat: MjStatistic;
  vis: MjVisual;
  flg_adhesion: boolean;
  flg_gravcomp: boolean;
  flg_surfacevel: boolean;
  nB: number;
  nC: number;
  nD: number;
  nJfe: number;
  nJfv: number;
  nJmom: number;
  nJten: number;
  nM: number;
  na: number;
  nactuator: number;
  narena: number;
  nbody: number;
  nbuffer: number;
  nbvh: number;
  nbvhdynamic: number;
  nbvhstatic: number;
  ncam: number;
  nconmax: number;
  nefm0L: number;
  nefm0dof: number;
  nemax: number;
  neq: number;
  nexclude: number;
  nflex: number;
  nflexbending: number;
  nflexedge: number;
  nflexelem: number;
  nflexelemdata: number;
  nflexelemedge: number;
  nflexevpair: number;
  nflexnode: number;
  nflexshelldata: number;
  nflexstiffness: number;
  nflextexcoord: number;
  nflexvert: number;
  ngeom: number;
  ngravcomp: number;
  nhfield: number;
  nhfielddata: number;
  nhistory: number;
  njmax: number;
  njnt: number;
  nkey: number;
  nlight: number;
  nmat: number;
  nmesh: number;
  nmeshdegmax: number;
  nmeshface: number;
  nmeshgraph: number;
  nmeshnormal: number;
  nmeshpoly: number;
  nmeshpolymap: number;
  nmeshpolyvert: number;
  nmeshtexcoord: number;
  nmeshvert: number;
  nmocap: number;
  nnames: number;
  nnames_map: number;
  nnumeric: number;
  nnumericdata: number;
  noct: number;
  nout: number;
  npair: number;
  npaths: number;
  nplugin: number;
  npluginattr: number;
  npluginstate: number;
  npolygonmax: number;
  nq: number;
  nsensor: number;
  nsensordata: number;
  nsite: number;
  nskin: number;
  nskinbone: number;
  nskinbonevert: number;
  nskinface: number;
  nskintexvert: number;
  nskinvert: number;
  ntendon: number;
  ntex: number;
  ntexdata: number;
  ntext: number;
  ntextdata: number;
  ntree: number;
  ntuple: number;
  ntupledata: number;
  nu: number;
  nuser_actuator: number;
  nuser_body: number;
  nuser_cam: number;
  nuser_geom: number;
  nuser_jnt: number;
  nuser_sensor: number;
  nuser_site: number;
  nuser_tendon: number;
  nuserdata: number;
  nv: number;
  nwrap: number;
  signature: bigint;
  readonly B_colind: any;
  readonly B_rowadr: any;
  readonly B_rownnz: any;
  readonly D_colind: any;
  readonly D_diag: any;
  readonly D_rowadr: any;
  readonly D_rownnz: any;
  readonly M_colind: any;
  readonly M_rowadr: any;
  readonly M_rownnz: any;
  readonly actuator_acc0: any;
  readonly actuator_actadr: any;
  readonly actuator_actearly: any;
  readonly actuator_actlimited: any;
  readonly actuator_actnum: any;
  readonly actuator_actrange: any;
  readonly actuator_armature: any;
  readonly actuator_biasprm: any;
  readonly actuator_biastype: any;
  readonly actuator_cranklength: any;
  readonly actuator_ctrladr: any;
  readonly actuator_ctrllimited: any;
  readonly actuator_ctrlnum: any;
  readonly actuator_ctrlrange: any;
  readonly actuator_ctrlspec: any;
  readonly actuator_damping: any;
  readonly actuator_dampingpoly: any;
  readonly actuator_delay: any;
  readonly actuator_dynprm: any;
  readonly actuator_dyntype: any;
  readonly actuator_forcelimited: any;
  readonly actuator_forcerange: any;
  readonly actuator_gainprm: any;
  readonly actuator_gaintype: any;
  readonly actuator_gear: any;
  readonly actuator_group: any;
  readonly actuator_history: any;
  readonly actuator_historyadr: any;
  readonly actuator_length0: any;
  readonly actuator_lengthrange: any;
  readonly actuator_outadr: any;
  readonly actuator_outnum: any;
  readonly actuator_plugin: any;
  readonly actuator_trnid: any;
  readonly actuator_trntype: any;
  readonly actuator_user: any;
  readonly body_bvhadr: any;
  readonly body_bvhnum: any;
  readonly body_conaffinity: any;
  readonly body_contype: any;
  readonly body_dofadr: any;
  readonly body_dofnum: any;
  readonly body_geomadr: any;
  readonly body_geomnum: any;
  readonly body_gravcomp: any;
  readonly body_inertia: any;
  readonly body_invweight0: any;
  readonly body_ipos: any;
  readonly body_iquat: any;
  readonly body_jntadr: any;
  readonly body_jntnum: any;
  readonly body_margin: any;
  readonly body_mass: any;
  readonly body_mocapid: any;
  readonly body_parentid: any;
  readonly body_plugin: any;
  readonly body_pos: any;
  readonly body_quat: any;
  readonly body_rootid: any;
  readonly body_sameframe: any;
  readonly body_simple: any;
  readonly body_subtreemass: any;
  readonly body_treeid: any;
  readonly body_user: any;
  readonly body_weldid: any;
  readonly buffer: any;
  readonly bvh_aabb: any;
  readonly bvh_child: any;
  readonly bvh_depth: any;
  readonly bvh_nodeid: any;
  readonly cam_bodyid: any;
  readonly cam_fovy: any;
  readonly cam_intrinsic: any;
  readonly cam_ipd: any;
  readonly cam_mat0: any;
  readonly cam_mode: any;
  readonly cam_output: any;
  readonly cam_pos: any;
  readonly cam_pos0: any;
  readonly cam_poscom0: any;
  readonly cam_projection: any;
  readonly cam_quat: any;
  readonly cam_resolution: any;
  readonly cam_sensorsize: any;
  readonly cam_targetbodyid: any;
  readonly cam_user: any;
  readonly dof_M0: any;
  readonly dof_Madr: any;
  readonly dof_armature: any;
  readonly dof_bodyid: any;
  readonly dof_damping: any;
  readonly dof_dampingpoly: any;
  readonly dof_frictionloss: any;
  readonly dof_invweight0: any;
  readonly dof_jntid: any;
  readonly dof_length: any;
  readonly dof_parentid: any;
  readonly dof_simplenum: any;
  readonly dof_solimp: any;
  readonly dof_solref: any;
  readonly dof_treeid: any;
  readonly efm0_L: any;
  readonly efm0_L_colind: any;
  readonly efm0_L_rowadr: any;
  readonly efm0_L_rownnz: any;
  readonly efm0_dofid: any;
  readonly eq_active0: any;
  readonly eq_data: any;
  readonly eq_obj1id: any;
  readonly eq_obj2id: any;
  readonly eq_objtype: any;
  readonly eq_solimp: any;
  readonly eq_solref: any;
  readonly eq_type: any;
  readonly exclude_signature: any;
  readonly flex_activelayers: any;
  readonly flex_bending: any;
  readonly flex_bendingadr: any;
  readonly flex_bvhadr: any;
  readonly flex_bvhnum: any;
  readonly flex_cellnum: any;
  readonly flex_centered: any;
  readonly flex_conaffinity: any;
  readonly flex_condim: any;
  readonly flex_contype: any;
  readonly flex_damping: any;
  readonly flex_dim: any;
  readonly flex_edge: any;
  readonly flex_edgeadr: any;
  readonly flex_edgedamping: any;
  readonly flex_edgeequality: any;
  readonly flex_edgeflap: any;
  readonly flex_edgenum: any;
  readonly flex_edgestiffness: any;
  readonly flex_elem: any;
  readonly flex_elemadr: any;
  readonly flex_elemdataadr: any;
  readonly flex_elemedge: any;
  readonly flex_elemedgeadr: any;
  readonly flex_elemlayer: any;
  readonly flex_elemnum: any;
  readonly flex_elemtexcoord: any;
  readonly flex_evpair: any;
  readonly flex_evpairadr: any;
  readonly flex_evpairnum: any;
  readonly flex_flatskin: any;
  readonly flex_friction: any;
  readonly flex_gap: any;
  readonly flex_group: any;
  readonly flex_internal: any;
  readonly flex_interp: any;
  readonly flex_margin: any;
  readonly flex_matid: any;
  readonly flex_node: any;
  readonly flex_node0: any;
  readonly flex_nodeadr: any;
  readonly flex_nodebodyid: any;
  readonly flex_nodenum: any;
  readonly flex_passive: any;
  readonly flex_priority: any;
  readonly flex_radius: any;
  readonly flex_rgba: any;
  readonly flex_rigid: any;
  readonly flex_selfcollide: any;
  readonly flex_shell: any;
  readonly flex_shelldataadr: any;
  readonly flex_shellnum: any;
  readonly flex_size: any;
  readonly flex_solimp: any;
  readonly flex_solmix: any;
  readonly flex_solref: any;
  readonly flex_stiffness: any;
  readonly flex_stiffnessadr: any;
  readonly flex_texcoord: any;
  readonly flex_texcoordadr: any;
  readonly flex_vert: any;
  readonly flex_vert0: any;
  readonly flex_vertadr: any;
  readonly flex_vertbodyid: any;
  readonly flex_vertedge: any;
  readonly flex_vertedgeadr: any;
  readonly flex_vertedgenum: any;
  readonly flex_vertmetric: any;
  readonly flex_vertnum: any;
  readonly flexedge_J_colind: any;
  readonly flexedge_J_rowadr: any;
  readonly flexedge_J_rownnz: any;
  readonly flexedge_invweight0: any;
  readonly flexedge_length0: any;
  readonly flexedge_rigid: any;
  readonly flexvert_J_colind: any;
  readonly flexvert_J_rowadr: any;
  readonly flexvert_J_rownnz: any;
  readonly geom_aabb: any;
  readonly geom_adhesion: any;
  readonly geom_bodyid: any;
  readonly geom_conaffinity: any;
  readonly geom_condim: any;
  readonly geom_contype: any;
  readonly geom_dataid: any;
  readonly geom_fluid: any;
  readonly geom_friction: any;
  readonly geom_gap: any;
  readonly geom_group: any;
  readonly geom_margin: any;
  readonly geom_matid: any;
  readonly geom_plugin: any;
  readonly geom_pos: any;
  readonly geom_priority: any;
  readonly geom_quat: any;
  readonly geom_rbound: any;
  readonly geom_rgba: any;
  readonly geom_sameframe: any;
  readonly geom_size: any;
  readonly geom_solimp: any;
  readonly geom_solmix: any;
  readonly geom_solref: any;
  readonly geom_surfacevel: any;
  readonly geom_type: any;
  readonly geom_user: any;
  readonly hfield_adr: any;
  readonly hfield_data: any;
  readonly hfield_ncol: any;
  readonly hfield_nrow: any;
  readonly hfield_pathadr: any;
  readonly hfield_size: any;
  readonly jnt_actfrclimited: any;
  readonly jnt_actfrcrange: any;
  readonly jnt_actgravcomp: any;
  readonly jnt_actuatorid: any;
  readonly jnt_axis: any;
  readonly jnt_bodyid: any;
  readonly jnt_dofadr: any;
  readonly jnt_group: any;
  readonly jnt_limited: any;
  readonly jnt_margin: any;
  readonly jnt_pos: any;
  readonly jnt_qposadr: any;
  readonly jnt_range: any;
  readonly jnt_solimp: any;
  readonly jnt_solref: any;
  readonly jnt_stiffness: any;
  readonly jnt_stiffnesspoly: any;
  readonly jnt_type: any;
  readonly jnt_user: any;
  readonly key_act: any;
  readonly key_ctrl: any;
  readonly key_mpos: any;
  readonly key_mquat: any;
  readonly key_qpos: any;
  readonly key_qvel: any;
  readonly key_time: any;
  readonly light_active: any;
  readonly light_ambient: any;
  readonly light_attenuation: any;
  readonly light_bodyid: any;
  readonly light_bulbradius: any;
  readonly light_castshadow: any;
  readonly light_cutoff: any;
  readonly light_diffuse: any;
  readonly light_dir: any;
  readonly light_dir0: any;
  readonly light_exponent: any;
  readonly light_intensity: any;
  readonly light_mode: any;
  readonly light_pos: any;
  readonly light_pos0: any;
  readonly light_poscom0: any;
  readonly light_range: any;
  readonly light_softness: any;
  readonly light_specular: any;
  readonly light_targetbodyid: any;
  readonly light_texid: any;
  readonly light_type: any;
  readonly mapD2M: any;
  readonly mapM2D: any;
  readonly mapM2M: any;
  readonly mat_emission: any;
  readonly mat_metallic: any;
  readonly mat_reflectance: any;
  readonly mat_rgba: any;
  readonly mat_roughness: any;
  readonly mat_shininess: any;
  readonly mat_specular: any;
  readonly mat_texid: any;
  readonly mat_texrepeat: any;
  readonly mat_texuniform: any;
  readonly mesh_bvhadr: any;
  readonly mesh_bvhnum: any;
  readonly mesh_extrema: any;
  readonly mesh_face: any;
  readonly mesh_faceadr: any;
  readonly mesh_facenormal: any;
  readonly mesh_facenum: any;
  readonly mesh_facetexcoord: any;
  readonly mesh_graph: any;
  readonly mesh_graphadr: any;
  readonly mesh_normal: any;
  readonly mesh_normaladr: any;
  readonly mesh_normalnum: any;
  readonly mesh_octadr: any;
  readonly mesh_octnum: any;
  readonly mesh_pathadr: any;
  readonly mesh_polyadr: any;
  readonly mesh_polymap: any;
  readonly mesh_polymapadr: any;
  readonly mesh_polymapnum: any;
  readonly mesh_polynormal: any;
  readonly mesh_polynum: any;
  readonly mesh_polyvert: any;
  readonly mesh_polyvertadr: any;
  readonly mesh_polyvertnum: any;
  readonly mesh_pos: any;
  readonly mesh_quat: any;
  readonly mesh_scale: any;
  readonly mesh_texcoord: any;
  readonly mesh_texcoordadr: any;
  readonly mesh_texcoordnum: any;
  readonly mesh_vert: any;
  readonly mesh_vertadr: any;
  readonly mesh_vertnum: any;
  readonly name_actuatoradr: any;
  readonly name_bodyadr: any;
  readonly name_camadr: any;
  readonly name_eqadr: any;
  readonly name_excludeadr: any;
  readonly name_flexadr: any;
  readonly name_geomadr: any;
  readonly name_hfieldadr: any;
  readonly name_jntadr: any;
  readonly name_keyadr: any;
  readonly name_lightadr: any;
  readonly name_matadr: any;
  readonly name_meshadr: any;
  readonly name_numericadr: any;
  readonly name_pairadr: any;
  readonly name_pluginadr: any;
  readonly name_sensoradr: any;
  readonly name_siteadr: any;
  readonly name_skinadr: any;
  readonly name_tendonadr: any;
  readonly name_texadr: any;
  readonly name_textadr: any;
  readonly name_tupleadr: any;
  readonly names: any;
  readonly names_map: any;
  readonly numeric_adr: any;
  readonly numeric_data: any;
  readonly numeric_size: any;
  readonly oct_aabb: any;
  readonly oct_child: any;
  readonly oct_coeff: any;
  readonly oct_depth: any;
  readonly pair_adhesion: any;
  readonly pair_dim: any;
  readonly pair_friction: any;
  readonly pair_gap: any;
  readonly pair_geom1: any;
  readonly pair_geom2: any;
  readonly pair_margin: any;
  readonly pair_signature: any;
  readonly pair_solimp: any;
  readonly pair_solref: any;
  readonly pair_solreffriction: any;
  readonly paths: any;
  readonly plugin: any;
  readonly plugin_attr: any;
  readonly plugin_attradr: any;
  readonly plugin_stateadr: any;
  readonly plugin_statenum: any;
  readonly qpos0: any;
  readonly qpos_spring: any;
  readonly sensor_adr: any;
  readonly sensor_cutoff: any;
  readonly sensor_datatype: any;
  readonly sensor_delay: any;
  readonly sensor_dim: any;
  readonly sensor_history: any;
  readonly sensor_historyadr: any;
  readonly sensor_interval: any;
  readonly sensor_intprm: any;
  readonly sensor_needstage: any;
  readonly sensor_noise: any;
  readonly sensor_objid: any;
  readonly sensor_objtype: any;
  readonly sensor_plugin: any;
  readonly sensor_refid: any;
  readonly sensor_reftype: any;
  readonly sensor_type: any;
  readonly sensor_user: any;
  readonly site_bodyid: any;
  readonly site_group: any;
  readonly site_matid: any;
  readonly site_pos: any;
  readonly site_quat: any;
  readonly site_rgba: any;
  readonly site_sameframe: any;
  readonly site_size: any;
  readonly site_type: any;
  readonly site_user: any;
  readonly skin_boneadr: any;
  readonly skin_bonebindpos: any;
  readonly skin_bonebindquat: any;
  readonly skin_bonebodyid: any;
  readonly skin_bonenum: any;
  readonly skin_bonevertadr: any;
  readonly skin_bonevertid: any;
  readonly skin_bonevertnum: any;
  readonly skin_bonevertweight: any;
  readonly skin_face: any;
  readonly skin_faceadr: any;
  readonly skin_facenum: any;
  readonly skin_group: any;
  readonly skin_inflate: any;
  readonly skin_matid: any;
  readonly skin_pathadr: any;
  readonly skin_rgba: any;
  readonly skin_texcoord: any;
  readonly skin_texcoordadr: any;
  readonly skin_vert: any;
  readonly skin_vertadr: any;
  readonly skin_vertnum: any;
  readonly ten_J_colind: any;
  readonly ten_J_rowadr: any;
  readonly ten_J_rownnz: any;
  readonly tendon_actfrclimited: any;
  readonly tendon_actfrcrange: any;
  readonly tendon_actuatorid: any;
  readonly tendon_adr: any;
  readonly tendon_armature: any;
  readonly tendon_damping: any;
  readonly tendon_dampingpoly: any;
  readonly tendon_frictionloss: any;
  readonly tendon_group: any;
  readonly tendon_invweight0: any;
  readonly tendon_length0: any;
  readonly tendon_lengthspring: any;
  readonly tendon_limited: any;
  readonly tendon_margin: any;
  readonly tendon_matid: any;
  readonly tendon_num: any;
  readonly tendon_range: any;
  readonly tendon_rgba: any;
  readonly tendon_solimp_fri: any;
  readonly tendon_solimp_lim: any;
  readonly tendon_solref_fri: any;
  readonly tendon_solref_lim: any;
  readonly tendon_stiffness: any;
  readonly tendon_stiffnesspoly: any;
  readonly tendon_treeid: any;
  readonly tendon_treenum: any;
  readonly tendon_user: any;
  readonly tendon_width: any;
  readonly tex_adr: any;
  readonly tex_colorspace: any;
  readonly tex_data: any;
  readonly tex_height: any;
  readonly tex_nchannel: any;
  readonly tex_pathadr: any;
  readonly tex_type: any;
  readonly tex_width: any;
  readonly text_adr: any;
  readonly text_data: any;
  readonly text_size: any;
  readonly tree_bodyadr: any;
  readonly tree_bodynum: any;
  readonly tree_dofadr: any;
  readonly tree_dofnum: any;
  readonly tree_sleep_policy: any;
  readonly tuple_adr: any;
  readonly tuple_objid: any;
  readonly tuple_objprm: any;
  readonly tuple_objtype: any;
  readonly tuple_size: any;
  readonly wrap_objid: any;
  readonly wrap_prm: any;
  readonly wrap_type: any;
  actuator(_0: number|string): MjModelActuatorAccessor;
  body(_0: number|string): MjModelBodyAccessor;
  cam(_0: number|string): MjModelCameraAccessor;
  eq(_0: number|string): MjModelEqualityAccessor;
  exclude(_0: number|string): MjModelExcludeAccessor;
  geom(_0: number|string): MjModelGeomAccessor;
  hfield(_0: number|string): MjModelHfieldAccessor;
  jnt(_0: number|string): MjModelJointAccessor;
  light(_0: number|string): MjModelLightAccessor;
  mat(_0: number|string): MjModelMaterialAccessor;
  mesh(_0: number|string): MjModelMeshAccessor;
  numeric(_0: number|string): MjModelNumericAccessor;
  pair(_0: number|string): MjModelPairAccessor;
  sensor(_0: number|string): MjModelSensorAccessor;
  site(_0: number|string): MjModelSiteAccessor;
  skin(_0: number|string): MjModelSkinAccessor;
  tendon(_0: number|string): MjModelTendonAccessor;
  tex(_0: number|string): MjModelTextureAccessor;
  tuple(_0: number|string): MjModelTupleAccessor;
  key(_0: number|string): MjModelKeyframeAccessor;
}

export interface MjOption extends ClassHandle {
  ccd_iterations: number;
  cone: number;
  disableactuator: number;
  disableflags: number;
  enableflags: number;
  integrator: number;
  iterations: number;
  jacobian: number;
  ls_iterations: number;
  noslip_iterations: number;
  sdf_initpoints: number;
  sdf_iterations: number;
  solver: number;
  ccd_tolerance: number;
  density: number;
  impratio: number;
  ls_tolerance: number;
  noslip_tolerance: number;
  o_margin: number;
  sleep_tolerance: number;
  timestep: number;
  tolerance: number;
  viscosity: number;
  readonly gravity: any;
  readonly magnetic: any;
  readonly o_friction: any;
  readonly o_solimp: any;
  readonly o_solref: any;
  readonly wind: any;
  copy(): MjOption;
}

export interface MjPreContact extends ClassHandle {
  dist: number;
  readonly normal: any;
  readonly pos: any;
  readonly tangent: any;
  copy(): MjPreContact;
}

export interface MjSolverStat extends ClassHandle {
  nactive: number;
  nchange: number;
  neval: number;
  nupdate: number;
  gradient: number;
  improvement: number;
  lineslope: number;
  copy(): MjSolverStat;
}

export interface MjSpec extends ClassHandle {
  option: MjOption;
  stat: MjStatistic;
  visual: MjVisual;
  authored: MjsAuthored;
  compiler: MjsCompiler;
  element: MjsElement;
  hasImplicitPluginElem: boolean;
  strippath: boolean;
  memory: number;
  nconmax: number;
  nemax: number;
  njmax: number;
  nkey: number;
  nstack: number;
  nuser_actuator: number;
  nuser_body: number;
  nuser_cam: number;
  nuser_geom: number;
  nuser_jnt: number;
  nuser_sensor: number;
  nuser_site: number;
  nuser_tendon: number;
  nuserdata: number;
  get comment(): string;
  set comment(value: EmbindString);
  get modelfiledir(): string;
  set modelfiledir(value: EmbindString);
  get modelname(): string;
  set modelname(value: EmbindString);
  readonly timer: any;
}

export interface MjStatistic extends ClassHandle {
  extent: number;
  meaninertia: number;
  meanmass: number;
  meansize: number;
  readonly center: any;
  copy(): MjStatistic;
}

export interface MjTimerStat extends ClassHandle {
  number: number;
  duration: number;
  copy(): MjTimerStat;
}

export interface MjVisual extends ClassHandle {
  global: MjVisualGlobal;
  headlight: MjVisualHeadlight;
  map: MjVisualMap;
  quality: MjVisualQuality;
  rgba: MjVisualRgba;
  scale: MjVisualScale;
  copy(): MjVisual;
}

export interface MjVisualGlobal extends ClassHandle {
  bvactive: number;
  cameraid: number;
  ellipsoidinertia: number;
  offheight: number;
  offwidth: number;
  orthographic: number;
  azimuth: number;
  elevation: number;
  fovy: number;
  glow: number;
  ipd: number;
  linewidth: number;
  realtime: number;
  copy(): MjVisualGlobal;
}

export interface MjVisualHeadlight extends ClassHandle {
  active: number;
  readonly ambient: any;
  readonly diffuse: any;
  readonly specular: any;
  copy(): MjVisualHeadlight;
}

export interface MjVisualMap extends ClassHandle {
  actuatortendon: number;
  alpha: number;
  fogend: number;
  fogstart: number;
  force: number;
  haze: number;
  shadowclip: number;
  shadowscale: number;
  stiffness: number;
  stiffnessrot: number;
  torque: number;
  zfar: number;
  znear: number;
  copy(): MjVisualMap;
}

export interface MjVisualQuality extends ClassHandle {
  numquads: number;
  numslices: number;
  numstacks: number;
  offsamples: number;
  shadowsize: number;
  copy(): MjVisualQuality;
}

export interface MjVisualRgba extends ClassHandle {
  readonly actuator: any;
  readonly actuatornegative: any;
  readonly actuatorpositive: any;
  readonly bv: any;
  readonly bvactive: any;
  readonly camera: any;
  readonly com: any;
  readonly connect: any;
  readonly constraint: any;
  readonly contactforce: any;
  readonly contactfriction: any;
  readonly contactgap: any;
  readonly contactpoint: any;
  readonly contacttorque: any;
  readonly crankbroken: any;
  readonly fog: any;
  readonly force: any;
  readonly frustum: any;
  readonly haze: any;
  readonly inertia: any;
  readonly joint: any;
  readonly light: any;
  readonly rangefinder: any;
  readonly selectpoint: any;
  readonly slidercrank: any;
  copy(): MjVisualRgba;
}

export interface MjVisualScale extends ClassHandle {
  actuatorlength: number;
  actuatorwidth: number;
  camera: number;
  com: number;
  connect: number;
  constraint: number;
  contactheight: number;
  contactwidth: number;
  forcewidth: number;
  framelength: number;
  framewidth: number;
  frustum: number;
  jointlength: number;
  jointwidth: number;
  light: number;
  selectpoint: number;
  slidercrank: number;
  copy(): MjVisualScale;
}

export interface MjWarningStat extends ClassHandle {
  lastinfo: number;
  number: number;
  copy(): MjWarningStat;
}

export interface MjsActuator extends ClassHandle {
  actlimited: mjtLimited;
  biastype: mjtBias;
  ctrllimited: mjtLimited;
  dyntype: mjtDyn;
  forcelimited: mjtLimited;
  gaintype: mjtGain;
  trntype: mjtTrn;
  element: MjsElement;
  plugin: MjsPlugin;
  readonly userdata: mjDoubleVec;
  actearly: boolean;
  actdim: number;
  ctrlspec: number;
  group: number;
  interp: number;
  nsample: number;
  armature: number;
  cranklength: number;
  delay: number;
  inheritrange: number;
  get info(): string;
  set info(value: EmbindString);
  get refsite(): string;
  set refsite(value: EmbindString);
  get slidersite(): string;
  set slidersite(value: EmbindString);
  get target(): string;
  set target(value: EmbindString);
  readonly actrange: any;
  readonly biasprm: any;
  readonly ctrlrange: any;
  readonly damping: any;
  readonly dynprm: any;
  readonly ffrange: any;
  readonly forcerange: any;
  readonly gainprm: any;
  readonly gear: any;
  readonly lengthrange: any;
  readonly velrange: any;
}

export interface MjsAuthored extends ClassHandle {
  disableactuator: number;
  disableflags: number;
  enableflags: number;
  option: bigint;
  visual_global: bigint;
  visual_headlight: bigint;
  visual_map: bigint;
  visual_quality: bigint;
  visual_rgba: bigint;
  visual_scale: bigint;
}

export interface MjsBody extends ClassHandle {
  sleep: mjtSleepPolicy;
  element: MjsElement;
  alt: MjsOrientation;
  ialt: MjsOrientation;
  plugin: MjsPlugin;
  readonly userdata: mjDoubleVec;
  explicitinertial: boolean;
  mocap: boolean;
  simple: number;
  gravcomp: number;
  mass: number;
  get childclass(): string;
  set childclass(value: EmbindString);
  get info(): string;
  set info(value: EmbindString);
  readonly fullinertia: any;
  readonly inertia: any;
  readonly ipos: any;
  readonly iquat: any;
  readonly pos: any;
  readonly quat: any;
}

export interface MjsCamera extends ClassHandle {
  mode: mjtCamLight;
  proj: mjtProjection;
  element: MjsElement;
  alt: MjsOrientation;
  readonly userdata: mjDoubleVec;
  output: number;
  fovy: number;
  ipd: number;
  get info(): string;
  set info(value: EmbindString);
  get targetbody(): string;
  set targetbody(value: EmbindString);
  readonly focal_length: any;
  readonly focal_pixel: any;
  readonly intrinsic: any;
  readonly pos: any;
  readonly principal_length: any;
  readonly principal_pixel: any;
  readonly quat: any;
  readonly resolution: any;
  readonly sensor_size: any;
}

export interface MjsCompiler extends ClassHandle {
  LRopt: MjLROpt;
  conflict: mjtConflict;
  inertiafromgeom: mjtInertiaFromGeom;
  alignfree: boolean;
  autolimits: boolean;
  balanceinertia: boolean;
  degree: boolean;
  discardvisual: boolean;
  fitaabb: boolean;
  fusestatic: boolean;
  saveinertial: boolean;
  usethread: boolean;
  authored: bigint;
  boundinertia: number;
  boundmass: number;
  settotalmass: number;
  get meshdir(): string;
  set meshdir(value: EmbindString);
  get texturedir(): string;
  set texturedir(value: EmbindString);
  readonly eulerseq: any;
  readonly inertiagrouprange: any;
}

export interface MjsDefault extends ClassHandle {
  actuator: MjsActuator;
  camera: MjsCamera;
  element: MjsElement;
  equality: MjsEquality;
  flex: MjsFlex;
  geom: MjsGeom;
  joint: MjsJoint;
  light: MjsLight;
  material: MjsMaterial;
  mesh: MjsMesh;
  pair: MjsPair;
  site: MjsSite;
  tendon: MjsTendon;
}

export interface MjsElement extends ClassHandle {
  elemtype: mjtObj;
  signature: bigint;
}

export interface MjsEquality extends ClassHandle {
  element: MjsElement;
  objtype: mjtObj;
  type: mjtEq;
  active: boolean;
  get info(): string;
  set info(value: EmbindString);
  get name1(): string;
  set name1(value: EmbindString);
  get name2(): string;
  set name2(value: EmbindString);
  readonly data: any;
  readonly solimp: any;
  readonly solref: any;
}

export interface MjsExclude extends ClassHandle {
  element: MjsElement;
  get bodyname1(): string;
  set bodyname1(value: EmbindString);
  get bodyname2(): string;
  set bodyname2(value: EmbindString);
  get info(): string;
  set info(value: EmbindString);
}

export interface MjsFlex extends ClassHandle {
  element: MjsElement;
  selfcollide: mjtFlexSelf;
  readonly nodebody: mjStringVec;
  readonly vertbody: mjStringVec;
  readonly elem: mjIntVec;
  readonly elemtexcoord: mjIntVec;
  readonly texcoord: mjFloatVec;
  readonly node: mjDoubleVec;
  readonly vert: mjDoubleVec;
  flatskin: boolean;
  internal: boolean;
  activelayers: number;
  conaffinity: number;
  condim: number;
  contype: number;
  dim: number;
  elastic2d: number;
  group: number;
  order: number;
  passive: number;
  priority: number;
  damping: number;
  edgedamping: number;
  edgestiffness: number;
  gap: number;
  margin: number;
  poisson: number;
  radius: number;
  solmix: number;
  thickness: number;
  young: number;
  get info(): string;
  set info(value: EmbindString);
  get material(): string;
  set material(value: EmbindString);
  readonly cellcount: any;
  readonly friction: any;
  readonly rgba: any;
  readonly size: any;
  readonly solimp: any;
  readonly solref: any;
}

export interface MjsFrame extends ClassHandle {
  element: MjsElement;
  alt: MjsOrientation;
  get childclass(): string;
  set childclass(value: EmbindString);
  get info(): string;
  set info(value: EmbindString);
  readonly pos: any;
  readonly quat: any;
}

export interface MjsGeom extends ClassHandle {
  element: MjsElement;
  type: mjtGeom;
  typeinertia: mjtGeomInertia;
  alt: MjsOrientation;
  plugin: MjsPlugin;
  readonly userdata: mjDoubleVec;
  conaffinity: number;
  condim: number;
  contype: number;
  group: number;
  priority: number;
  adhesion: number;
  density: number;
  fitscale: number;
  fluid_ellipsoid: number;
  gap: number;
  margin: number;
  mass: number;
  solmix: number;
  get hfieldname(): string;
  set hfieldname(value: EmbindString);
  get info(): string;
  set info(value: EmbindString);
  get material(): string;
  set material(value: EmbindString);
  get meshname(): string;
  set meshname(value: EmbindString);
  readonly fluid_coefs: any;
  readonly friction: any;
  readonly fromto: any;
  readonly pos: any;
  readonly quat: any;
  readonly rgba: any;
  readonly size: any;
  readonly solimp: any;
  readonly solref: any;
  readonly surfacevel: any;
}

export interface MjsHField extends ClassHandle {
  element: MjsElement;
  readonly userdata: mjFloatVec;
  ncol: number;
  nrow: number;
  get content_type(): string;
  set content_type(value: EmbindString);
  get file(): string;
  set file(value: EmbindString);
  get info(): string;
  set info(value: EmbindString);
  readonly size: any;
}

export interface MjsJoint extends ClassHandle {
  actfrclimited: mjtLimited;
  align: mjtAlignFree;
  element: MjsElement;
  limited: mjtLimited;
  type: mjtJoint;
  readonly userdata: mjDoubleVec;
  actgravcomp: boolean;
  group: number;
  armature: number;
  frictionloss: number;
  margin: number;
  ref: number;
  springref: number;
  get info(): string;
  set info(value: EmbindString);
  readonly actfrcrange: any;
  readonly axis: any;
  readonly damping: any;
  readonly pos: any;
  readonly range: any;
  readonly solimp_friction: any;
  readonly solimp_limit: any;
  readonly solref_friction: any;
  readonly solref_limit: any;
  readonly springdamper: any;
  readonly stiffness: any;
}

export interface MjsKey extends ClassHandle {
  element: MjsElement;
  readonly act: mjDoubleVec;
  readonly ctrl: mjDoubleVec;
  readonly mpos: mjDoubleVec;
  readonly mquat: mjDoubleVec;
  readonly qpos: mjDoubleVec;
  readonly qvel: mjDoubleVec;
  time: number;
  get info(): string;
  set info(value: EmbindString);
}

export interface MjsLight extends ClassHandle {
  element: MjsElement;
  mode: mjtCamLight;
  type: mjtLightType;
  active: boolean;
  castshadow: boolean;
  bulbradius: number;
  cutoff: number;
  exponent: number;
  intensity: number;
  range: number;
  softness: number;
  get info(): string;
  set info(value: EmbindString);
  get targetbody(): string;
  set targetbody(value: EmbindString);
  get texture(): string;
  set texture(value: EmbindString);
  readonly ambient: any;
  readonly attenuation: any;
  readonly diffuse: any;
  readonly dir: any;
  readonly pos: any;
  readonly specular: any;
}

export interface MjsMaterial extends ClassHandle {
  element: MjsElement;
  readonly textures: mjStringVec;
  texuniform: boolean;
  emission: number;
  metallic: number;
  reflectance: number;
  roughness: number;
  shininess: number;
  specular: number;
  get info(): string;
  set info(value: EmbindString);
  readonly rgba: any;
  readonly texrepeat: any;
}

export interface MjsMesh extends ClassHandle {
  element: MjsElement;
  inertia: mjtMeshInertia;
  plugin: MjsPlugin;
  readonly userface: mjIntVec;
  readonly userfacenormal: mjIntVec;
  readonly userfacetexcoord: mjIntVec;
  readonly usernormal: mjFloatVec;
  readonly usertexcoord: mjFloatVec;
  readonly uservert: mjFloatVec;
  needsdf: boolean;
  smoothnormal: boolean;
  maxhullvert: number;
  octree_maxdepth: number;
  get content_type(): string;
  set content_type(value: EmbindString);
  get file(): string;
  set file(value: EmbindString);
  get info(): string;
  set info(value: EmbindString);
  get material(): string;
  set material(value: EmbindString);
  readonly refpos: any;
  readonly refquat: any;
  readonly scale: any;
}

export interface MjsNumeric extends ClassHandle {
  element: MjsElement;
  readonly data: mjDoubleVec;
  size: number;
  get info(): string;
  set info(value: EmbindString);
}

export interface MjsOrientation extends ClassHandle {
  type: mjtOrientation;
  readonly axisangle: any;
  readonly euler: any;
  readonly xyaxes: any;
  readonly zaxis: any;
}

export interface MjsPair extends ClassHandle {
  element: MjsElement;
  condim: number;
  adhesion: number;
  gap: number;
  margin: number;
  get geomname1(): string;
  set geomname1(value: EmbindString);
  get geomname2(): string;
  set geomname2(value: EmbindString);
  get info(): string;
  set info(value: EmbindString);
  readonly friction: any;
  readonly solimp: any;
  readonly solref: any;
  readonly solreffriction: any;
}

export interface MjsPlugin extends ClassHandle {
  element: MjsElement;
  active: boolean;
  get info(): string;
  set info(value: EmbindString);
  get name(): string;
  set name(value: EmbindString);
  get plugin_name(): string;
  set plugin_name(value: EmbindString);
}

export interface MjsSensor extends ClassHandle {
  datatype: mjtDataType;
  element: MjsElement;
  needstage: mjtStage;
  objtype: mjtObj;
  plugin: MjsPlugin;
  reftype: mjtObj;
  type: mjtSensor;
  readonly userdata: mjDoubleVec;
  dim: number;
  interp: number;
  nsample: number;
  cutoff: number;
  delay: number;
  noise: number;
  get info(): string;
  set info(value: EmbindString);
  get objname(): string;
  set objname(value: EmbindString);
  get refname(): string;
  set refname(value: EmbindString);
  readonly interval: any;
  readonly intprm: any;
}

export interface MjsSite extends ClassHandle {
  alt: MjsOrientation;
  element: MjsElement;
  type: mjtGeom;
  readonly userdata: mjDoubleVec;
  group: number;
  get info(): string;
  set info(value: EmbindString);
  get material(): string;
  set material(value: EmbindString);
  readonly fromto: any;
  readonly pos: any;
  readonly quat: any;
  readonly rgba: any;
  readonly size: any;
}

export interface MjsSkin extends ClassHandle {
  element: MjsElement;
  readonly bodyname: mjStringVec;
  readonly face: mjIntVec;
  readonly vertid: mjIntVecVec;
  readonly bindpos: mjFloatVec;
  readonly bindquat: mjFloatVec;
  readonly texcoord: mjFloatVec;
  readonly vert: mjFloatVec;
  readonly vertweight: mjFloatVecVec;
  group: number;
  inflate: number;
  get file(): string;
  set file(value: EmbindString);
  get info(): string;
  set info(value: EmbindString);
  get material(): string;
  set material(value: EmbindString);
  readonly rgba: any;
}

export interface MjsTendon extends ClassHandle {
  actfrclimited: mjtLimited;
  element: MjsElement;
  limited: mjtLimited;
  readonly userdata: mjDoubleVec;
  group: number;
  armature: number;
  frictionloss: number;
  margin: number;
  width: number;
  get info(): string;
  set info(value: EmbindString);
  get material(): string;
  set material(value: EmbindString);
  readonly actfrcrange: any;
  readonly damping: any;
  readonly range: any;
  readonly rgba: any;
  readonly solimp_friction: any;
  readonly solimp_limit: any;
  readonly solref_friction: any;
  readonly solref_limit: any;
  readonly springlength: any;
  readonly stiffness: any;
}

export interface MjsText extends ClassHandle {
  element: MjsElement;
  get data(): string;
  set data(value: EmbindString);
  get info(): string;
  set info(value: EmbindString);
}

export interface MjsTexture extends ClassHandle {
  builtin: mjtBuiltin;
  colorspace: mjtColorSpace;
  element: MjsElement;
  mark: mjtMark;
  type: mjtTexture;
  readonly cubefiles: mjStringVec;
  readonly data: mjByteVec;
  hflip: boolean;
  vflip: boolean;
  height: number;
  nchannel: number;
  width: number;
  random: number;
  get content_type(): string;
  set content_type(value: EmbindString);
  get file(): string;
  set file(value: EmbindString);
  get info(): string;
  set info(value: EmbindString);
  readonly gridlayout: any;
  readonly gridsize: any;
  readonly markrgb: any;
  readonly rgb1: any;
  readonly rgb2: any;
}

export interface MjsTuple extends ClassHandle {
  element: MjsElement;
  readonly objname: mjStringVec;
  readonly objtype: mjIntVec;
  readonly objprm: mjDoubleVec;
  get info(): string;
  set info(value: EmbindString);
}

export interface MjsWrap extends ClassHandle {
  element: MjsElement;
  type: mjtWrap;
  get info(): string;
  set info(value: EmbindString);
}

export interface MjvCamera extends ClassHandle {
  fixedcamid: number;
  orthographic: number;
  trackbodyid: number;
  type: number;
  azimuth: number;
  distance: number;
  elevation: number;
  readonly lookat: any;
  copy(): MjvCamera;
}

export interface MjvFigure extends ClassHandle {
  flg_barplot: number;
  flg_extend: number;
  flg_legend: number;
  flg_selection: number;
  flg_symmetric: number;
  highlightid: number;
  legendoffset: number;
  subplot: number;
  gridwidth: number;
  linewidth: number;
  selection: number;
  readonly figurergba: any;
  readonly flg_ticklabel: any;
  readonly gridrgb: any;
  readonly gridsize: any;
  readonly highlight: any;
  readonly legendrgba: any;
  readonly linedata: any;
  readonly linename: any;
  readonly linepnt: any;
  readonly linergb: any;
  readonly minwidth: any;
  readonly panergba: any;
  readonly range: any;
  readonly textrgb: any;
  readonly title: any;
  readonly xaxisdata: any;
  readonly xaxispixel: any;
  readonly xformat: any;
  readonly xlabel: any;
  readonly yaxisdata: any;
  readonly yaxispixel: any;
  readonly yformat: any;
  copy(): MjvFigure;
}

export interface MjvGLCamera extends ClassHandle {
  orthographic: number;
  frustum_bottom: number;
  frustum_center: number;
  frustum_far: number;
  frustum_near: number;
  frustum_top: number;
  frustum_width: number;
  readonly forward: any;
  readonly pos: any;
  readonly up: any;
  copy(): MjvGLCamera;
}

export interface MjvGeom extends ClassHandle {
  transparent: number;
  category: number;
  dataid: number;
  matid: number;
  objid: number;
  objtype: number;
  segid: number;
  texcoord: number;
  texid: number;
  texuniform: number;
  type: number;
  camdist: number;
  emission: number;
  modelrbound: number;
  reflectance: number;
  shininess: number;
  specular: number;
  readonly label: any;
  readonly mat: any;
  readonly pos: any;
  readonly rgba: any;
  readonly size: any;
  readonly texrepeat: any;
  copy(): MjvGeom;
}

export interface MjvLight extends ClassHandle {
  castshadow: number;
  headlight: number;
  id: number;
  texid: number;
  type: number;
  bulbradius: number;
  cutoff: number;
  exponent: number;
  intensity: number;
  range: number;
  softness: number;
  readonly ambient: any;
  readonly attenuation: any;
  readonly diffuse: any;
  readonly dir: any;
  readonly pos: any;
  readonly specular: any;
  copy(): MjvLight;
}

export interface MjvOption extends ClassHandle {
  bvh_depth: number;
  flex_layer: number;
  frame: number;
  label: number;
  readonly actuatorgroup: any;
  readonly flags: any;
  readonly flexgroup: any;
  readonly geomgroup: any;
  readonly jointgroup: any;
  readonly sitegroup: any;
  readonly skingroup: any;
  readonly tendongroup: any;
  copy(): MjvOption;
}

export interface MjvPerturb extends ClassHandle {
  active: number;
  active2: number;
  flexselect: number;
  select: number;
  skinselect: number;
  localmass: number;
  scale: number;
  readonly localpos: any;
  readonly refpos: any;
  readonly refquat: any;
  readonly refselpos: any;
  copy(): MjvPerturb;
}

export interface MjvScene extends ClassHandle {
  lights: MjvLightVec;
  camera: MjvGLCameraVec;
  readonly geoms: MjvGeomVec;
  enabletransform: number;
  flexedgeopt: number;
  flexfaceopt: number;
  flexskinopt: number;
  flexvertopt: number;
  framewidth: number;
  maxgeom: number;
  nflex: number;
  ngeom: number;
  nlight: number;
  nskin: number;
  status: number;
  stereo: number;
  scale: number;
  readonly flags: any;
  readonly flexedge: any;
  readonly flexedgeadr: any;
  readonly flexedgenum: any;
  readonly flexface: any;
  readonly flexfaceadr: any;
  readonly flexfacenum: any;
  readonly flexfaceused: any;
  readonly flexnormal: any;
  readonly flextexcoord: any;
  readonly flexvert: any;
  readonly flexvertadr: any;
  readonly flexvertnum: any;
  readonly framergb: any;
  readonly geomorder: any;
  readonly rotate: any;
  readonly skinfacenum: any;
  readonly skinnormal: any;
  readonly skinvert: any;
  readonly skinvertadr: any;
  readonly skinvertnum: any;
  readonly translate: any;
}

export interface MjVFS extends ClassHandle {
  deleteFile(_0: EmbindString): void;
  addBuffer(_0: EmbindString, _1: any): void;
}

export interface FloatBuffer extends ClassHandle {
  GetElementCount(): number;
  GetPointer(): number;
  GetView(): any;
}

export interface DoubleBuffer extends ClassHandle {
  GetElementCount(): number;
  GetPointer(): number;
  GetView(): any;
}

export interface IntBuffer extends ClassHandle {
  GetElementCount(): number;
  GetPointer(): number;
  GetView(): any;
}

export interface Uint8Buffer extends ClassHandle {
  GetElementCount(): number;
  GetPointer(): number;
  GetView(): any;
}

export interface mjStringVec extends ClassHandle {
  size(): number;
  get(_0: number): EmbindString | undefined;
  push_back(_0: EmbindString): void;
  resize(_0: number, _1: EmbindString): void;
  set(_0: number, _1: EmbindString): boolean;
}

export interface mjStringVecVec extends ClassHandle {
  push_back(_0: mjStringVec): void;
  resize(_0: number, _1: mjStringVec): void;
  size(): number;
  get(_0: number): mjStringVec | undefined;
  set(_0: number, _1: mjStringVec): boolean;
}

export interface mjIntVec extends ClassHandle {
  push_back(_0: number): void;
  resize(_0: number, _1: number): void;
  size(): number;
  get(_0: number): number | undefined;
  set(_0: number, _1: number): boolean;
}

export interface mjIntVecVec extends ClassHandle {
  push_back(_0: mjIntVec): void;
  resize(_0: number, _1: mjIntVec): void;
  size(): number;
  get(_0: number): mjIntVec | undefined;
  set(_0: number, _1: mjIntVec): boolean;
}

export interface mjFloatVec extends ClassHandle {
  size(): number;
  get(_0: number): number | undefined;
  push_back(_0: number): void;
  resize(_0: number, _1: number): void;
  set(_0: number, _1: number): boolean;
}

export interface mjFloatVecVec extends ClassHandle {
  push_back(_0: mjFloatVec): void;
  resize(_0: number, _1: mjFloatVec): void;
  size(): number;
  get(_0: number): mjFloatVec | undefined;
  set(_0: number, _1: mjFloatVec): boolean;
}

export interface mjDoubleVec extends ClassHandle {
  size(): number;
  get(_0: number): number | undefined;
  push_back(_0: number): void;
  resize(_0: number, _1: number): void;
  set(_0: number, _1: number): boolean;
}

export interface mjByteVec extends ClassHandle {
  push_back(_0: number): void;
  resize(_0: number, _1: number): void;
  size(): number;
  get(_0: number): number | undefined;
  set(_0: number, _1: number): boolean;
}

export interface MjSolverStatVec extends ClassHandle {
  push_back(_0: MjSolverStat): void;
  resize(_0: number, _1: MjSolverStat): void;
  size(): number;
  get(_0: number): MjSolverStat | undefined;
  set(_0: number, _1: MjSolverStat): boolean;
}

export interface MjTimerStatVec extends ClassHandle {
  push_back(_0: MjTimerStat): void;
  resize(_0: number, _1: MjTimerStat): void;
  size(): number;
  get(_0: number): MjTimerStat | undefined;
  set(_0: number, _1: MjTimerStat): boolean;
}

export interface MjWarningStatVec extends ClassHandle {
  push_back(_0: MjWarningStat): void;
  resize(_0: number, _1: MjWarningStat): void;
  size(): number;
  get(_0: number): MjWarningStat | undefined;
  set(_0: number, _1: MjWarningStat): boolean;
}

export interface MjContactVec extends ClassHandle {
  push_back(_0: MjContact): void;
  resize(_0: number, _1: MjContact): void;
  size(): number;
  get(_0: number): MjContact | undefined;
  set(_0: number, _1: MjContact): boolean;
}

export interface MjvLightVec extends ClassHandle {
  push_back(_0: MjvLight): void;
  resize(_0: number, _1: MjvLight): void;
  size(): number;
  get(_0: number): MjvLight | undefined;
  set(_0: number, _1: MjvLight): boolean;
}

export interface MjvGLCameraVec extends ClassHandle {
  push_back(_0: MjvGLCamera): void;
  resize(_0: number, _1: MjvGLCamera): void;
  size(): number;
  get(_0: number): MjvGLCamera | undefined;
  set(_0: number, _1: MjvGLCamera): boolean;
}

export interface MjvGeomVec extends ClassHandle {
  push_back(_0: MjvGeom): void;
  resize(_0: number, _1: MjvGeom): void;
  size(): number;
  get(_0: number): MjvGeom | undefined;
  set(_0: number, _1: MjvGeom): boolean;
}

interface EmbindModule {
  mjrIndexType: {mjINDEX_TYPE_U16: mjrIndexTypeValue<0>, mjINDEX_TYPE_U32: mjrIndexTypeValue<1>};
  mjrMeshPrimitiveType: {mjMESH_PRIMITIVE_TYPE_TRIANGLES: mjrMeshPrimitiveTypeValue<0>, mjMESH_PRIMITIVE_TYPE_LINES: mjrMeshPrimitiveTypeValue<1>};
  mjrPixelFormat: {mjPIXEL_FORMAT_UNKNOWN: mjrPixelFormatValue<0>, mjPIXEL_FORMAT_R8: mjrPixelFormatValue<1>, mjPIXEL_FORMAT_RGB8: mjrPixelFormatValue<2>, mjPIXEL_FORMAT_RGBA8: mjrPixelFormatValue<3>, mjPIXEL_FORMAT_R32F: mjrPixelFormatValue<4>, mjPIXEL_FORMAT_DEPTH32F: mjrPixelFormatValue<5>, mjPIXEL_FORMAT_KTX: mjrPixelFormatValue<6>};
  mjrVertexAttributeType: {mjVERTEX_ATTRIBUTE_TYPE_FLOAT2: mjrVertexAttributeTypeValue<0>, mjVERTEX_ATTRIBUTE_TYPE_FLOAT3: mjrVertexAttributeTypeValue<1>, mjVERTEX_ATTRIBUTE_TYPE_FLOAT4: mjrVertexAttributeTypeValue<2>, mjVERTEX_ATTRIBUTE_TYPE_UBYTE4: mjrVertexAttributeTypeValue<3>};
  mjrVertexAttributeUsage: {mjVERTEX_ATTRIBUTE_USAGE_POSITION: mjrVertexAttributeUsageValue<0>, mjVERTEX_ATTRIBUTE_USAGE_NORMAL: mjrVertexAttributeUsageValue<1>, mjVERTEX_ATTRIBUTE_USAGE_TANGENTS: mjrVertexAttributeUsageValue<2>, mjVERTEX_ATTRIBUTE_USAGE_UV: mjrVertexAttributeUsageValue<3>, mjVERTEX_ATTRIBUTE_USAGE_COLOR: mjrVertexAttributeUsageValue<4>};
  mjtAlignFree: {mjALIGNFREE_FALSE: mjtAlignFreeValue<0>, mjALIGNFREE_TRUE: mjtAlignFreeValue<1>, mjALIGNFREE_AUTO: mjtAlignFreeValue<2>};
  mjtBias: {mjBIAS_NONE: mjtBiasValue<0>, mjBIAS_AFFINE: mjtBiasValue<1>, mjBIAS_MUSCLE: mjtBiasValue<2>, mjBIAS_DCMOTOR: mjtBiasValue<3>, mjBIAS_SO3: mjtBiasValue<4>, mjBIAS_USER: mjtBiasValue<5>};
  mjtBuiltin: {mjBUILTIN_NONE: mjtBuiltinValue<0>, mjBUILTIN_GRADIENT: mjtBuiltinValue<1>, mjBUILTIN_CHECKER: mjtBuiltinValue<2>, mjBUILTIN_FLAT: mjtBuiltinValue<3>};
  mjtButton: {mjBUTTON_NONE: mjtButtonValue<0>, mjBUTTON_LEFT: mjtButtonValue<1>, mjBUTTON_RIGHT: mjtButtonValue<2>, mjBUTTON_MIDDLE: mjtButtonValue<3>};
  mjtCTimer: {mjCTIMER_TOTAL: mjtCTimerValue<0>, mjCTIMER_ASSETS: mjtCTimerValue<1>, mjCTIMER_TEXTURE: mjtCTimerValue<2>, mjCTIMER_MESH_LOAD: mjtCTimerValue<3>, mjCTIMER_MESH_HULL: mjtCTimerValue<4>, mjCTIMER_MESH_POLYGON: mjtCTimerValue<5>, mjCTIMER_MESH_INERTIA: mjtCTimerValue<6>, mjCTIMER_MESH_BVH: mjtCTimerValue<7>, mjCTIMER_MESH_OCTREE: mjtCTimerValue<8>, mjNCTIMER: mjtCTimerValue<9>};
  mjtCamLight: {mjCAMLIGHT_FIXED: mjtCamLightValue<0>, mjCAMLIGHT_TRACK: mjtCamLightValue<1>, mjCAMLIGHT_TRACKCOM: mjtCamLightValue<2>, mjCAMLIGHT_TARGETBODY: mjtCamLightValue<3>, mjCAMLIGHT_TARGETBODYCOM: mjtCamLightValue<4>};
  mjtCamOutBit: {mjCAMOUT_RGB: mjtCamOutBitValue<1>, mjCAMOUT_DEPTH: mjtCamOutBitValue<2>, mjCAMOUT_DIST: mjtCamOutBitValue<4>, mjCAMOUT_NORMAL: mjtCamOutBitValue<8>, mjCAMOUT_SEG: mjtCamOutBitValue<16>, mjNCAMOUT: mjtCamOutBitValue<5>};
  mjtCamera: {mjCAMERA_FREE: mjtCameraValue<0>, mjCAMERA_TRACKING: mjtCameraValue<1>, mjCAMERA_FIXED: mjtCameraValue<2>, mjCAMERA_USER: mjtCameraValue<3>};
  mjtCatBit: {mjCAT_STATIC: mjtCatBitValue<1>, mjCAT_DYNAMIC: mjtCatBitValue<2>, mjCAT_DECOR: mjtCatBitValue<4>, mjCAT_ALL: mjtCatBitValue<7>};
  mjtColorSpace: {mjCOLORSPACE_AUTO: mjtColorSpaceValue<0>, mjCOLORSPACE_LINEAR: mjtColorSpaceValue<1>, mjCOLORSPACE_SRGB: mjtColorSpaceValue<2>};
  mjtConDataField: {mjCONDATA_FOUND: mjtConDataFieldValue<0>, mjCONDATA_FORCE: mjtConDataFieldValue<1>, mjCONDATA_TORQUE: mjtConDataFieldValue<2>, mjCONDATA_DIST: mjtConDataFieldValue<3>, mjCONDATA_POS: mjtConDataFieldValue<4>, mjCONDATA_NORMAL: mjtConDataFieldValue<5>, mjCONDATA_TANGENT: mjtConDataFieldValue<6>, mjNCONDATA: mjtConDataFieldValue<7>};
  mjtCone: {mjCONE_PYRAMIDAL: mjtConeValue<0>, mjCONE_ELLIPTIC: mjtConeValue<1>};
  mjtConflict: {mjCONFLICT_WARNING: mjtConflictValue<0>, mjCONFLICT_MERGE: mjtConflictValue<1>, mjCONFLICT_ERROR: mjtConflictValue<2>};
  mjtConstraint: {mjCNSTR_EQUALITY: mjtConstraintValue<0>, mjCNSTR_FRICTION_DOF: mjtConstraintValue<1>, mjCNSTR_FRICTION_TENDON: mjtConstraintValue<2>, mjCNSTR_LIMIT_JOINT: mjtConstraintValue<3>, mjCNSTR_LIMIT_TENDON: mjtConstraintValue<4>, mjCNSTR_CONTACT_FRICTIONLESS: mjtConstraintValue<5>, mjCNSTR_CONTACT_PYRAMIDAL: mjtConstraintValue<6>, mjCNSTR_CONTACT_ELLIPTIC: mjtConstraintValue<7>};
  mjtConstraintState: {mjCNSTRSTATE_SATISFIED: mjtConstraintStateValue<0>, mjCNSTRSTATE_QUADRATIC: mjtConstraintStateValue<1>, mjCNSTRSTATE_LINEARNEG: mjtConstraintStateValue<2>, mjCNSTRSTATE_LINEARPOS: mjtConstraintStateValue<3>, mjCNSTRSTATE_CONE: mjtConstraintStateValue<4>};
  mjtCtrlChart: {mjCHART_EXPMAP: mjtCtrlChartValue<1>, mjCHART_QUAT: mjtCtrlChartValue<2>};
  mjtCtrlInput: {mjINPUT_POS: mjtCtrlInputValue<1>, mjINPUT_VEL: mjtCtrlInputValue<2>, mjINPUT_FF: mjtCtrlInputValue<4>, mjINPUT_VOLTAGE: mjtCtrlInputValue<8>, mjINPUT_NONE: mjtCtrlInputValue<16>};
  mjtDataType: {mjDATATYPE_REAL: mjtDataTypeValue<0>, mjDATATYPE_POSITIVE: mjtDataTypeValue<1>, mjDATATYPE_AXIS: mjtDataTypeValue<2>, mjDATATYPE_QUATERNION: mjtDataTypeValue<3>};
  mjtDepthMap: {mjDEPTH_ZERONEAR: mjtDepthMapValue<0>, mjDEPTH_ZEROFAR: mjtDepthMapValue<1>};
  mjtDisableBit: {mjDSBL_CONSTRAINT: mjtDisableBitValue<1>, mjDSBL_EQUALITY: mjtDisableBitValue<2>, mjDSBL_FRICTIONLOSS: mjtDisableBitValue<4>, mjDSBL_LIMIT: mjtDisableBitValue<8>, mjDSBL_CONTACT: mjtDisableBitValue<16>, mjDSBL_SPRING: mjtDisableBitValue<32>, mjDSBL_DAMPER: mjtDisableBitValue<64>, mjDSBL_GRAVITY: mjtDisableBitValue<128>, mjDSBL_CLAMPCTRL: mjtDisableBitValue<256>, mjDSBL_WARMSTART: mjtDisableBitValue<512>, mjDSBL_FILTERPARENT: mjtDisableBitValue<1024>, mjDSBL_ACTUATION: mjtDisableBitValue<2048>, mjDSBL_REFSAFE: mjtDisableBitValue<4096>, mjDSBL_SENSOR: mjtDisableBitValue<8192>, mjDSBL_MIDPHASE: mjtDisableBitValue<16384>, mjDSBL_EULERDAMP: mjtDisableBitValue<32768>, mjDSBL_AUTORESET: mjtDisableBitValue<65536>, mjDSBL_NATIVECCD: mjtDisableBitValue<131072>, mjDSBL_ISLAND: mjtDisableBitValue<262144>, mjDSBL_MULTICCD: mjtDisableBitValue<524288>, mjNDISABLE: mjtDisableBitValue<20>};
  mjtDyn: {mjDYN_NONE: mjtDynValue<0>, mjDYN_INTEGRATOR: mjtDynValue<1>, mjDYN_FILTER: mjtDynValue<2>, mjDYN_FILTEREXACT: mjtDynValue<3>, mjDYN_MUSCLE: mjtDynValue<4>, mjDYN_DCMOTOR: mjtDynValue<5>, mjDYN_PID: mjtDynValue<6>, mjDYN_USER: mjtDynValue<7>};
  mjtEnableBit: {mjENBL_OVERRIDE: mjtEnableBitValue<1>, mjENBL_ENERGY: mjtEnableBitValue<2>, mjENBL_FWDINV: mjtEnableBitValue<4>, mjENBL_INVDISCRETE: mjtEnableBitValue<8>, mjENBL_SLEEP: mjtEnableBitValue<16>, mjENBL_DIAGEXACT: mjtEnableBitValue<32>, mjNENABLE: mjtEnableBitValue<6>};
  mjtEq: {mjEQ_CONNECT: mjtEqValue<0>, mjEQ_WELD: mjtEqValue<1>, mjEQ_JOINT: mjtEqValue<2>, mjEQ_TENDON: mjtEqValue<3>, mjEQ_FLEX: mjtEqValue<4>, mjEQ_FLEXVERT: mjtEqValue<5>, mjEQ_FLEXSTRAIN: mjtEqValue<6>, mjEQ_DISTANCE: mjtEqValue<7>};
  mjtEvent: {mjEVENT_NONE: mjtEventValue<0>, mjEVENT_MOVE: mjtEventValue<1>, mjEVENT_PRESS: mjtEventValue<2>, mjEVENT_RELEASE: mjtEventValue<3>, mjEVENT_SCROLL: mjtEventValue<4>, mjEVENT_KEY: mjtEventValue<5>, mjEVENT_RESIZE: mjtEventValue<6>, mjEVENT_REDRAW: mjtEventValue<7>, mjEVENT_FILESDROP: mjtEventValue<8>};
  mjtFlexSelf: {mjFLEXSELF_NONE: mjtFlexSelfValue<0>, mjFLEXSELF_NARROW: mjtFlexSelfValue<1>, mjFLEXSELF_BVH: mjtFlexSelfValue<2>, mjFLEXSELF_SAP: mjtFlexSelfValue<3>, mjFLEXSELF_AUTO: mjtFlexSelfValue<4>};
  mjtFont: {mjFONT_NORMAL: mjtFontValue<0>, mjFONT_SHADOW: mjtFontValue<1>, mjFONT_BIG: mjtFontValue<2>};
  mjtFontScale: {mjFONTSCALE_50: mjtFontScaleValue<50>, mjFONTSCALE_100: mjtFontScaleValue<100>, mjFONTSCALE_150: mjtFontScaleValue<150>, mjFONTSCALE_200: mjtFontScaleValue<200>, mjFONTSCALE_250: mjtFontScaleValue<250>, mjFONTSCALE_300: mjtFontScaleValue<300>};
  mjtFrame: {mjFRAME_NONE: mjtFrameValue<0>, mjFRAME_BODY: mjtFrameValue<1>, mjFRAME_GEOM: mjtFrameValue<2>, mjFRAME_SITE: mjtFrameValue<3>, mjFRAME_CAMERA: mjtFrameValue<4>, mjFRAME_LIGHT: mjtFrameValue<5>, mjFRAME_CONTACT: mjtFrameValue<6>, mjFRAME_WORLD: mjtFrameValue<7>, mjNFRAME: mjtFrameValue<8>};
  mjtFramebuffer: {mjFB_WINDOW: mjtFramebufferValue<0>, mjFB_OFFSCREEN: mjtFramebufferValue<1>};
  mjtGain: {mjGAIN_FIXED: mjtGainValue<0>, mjGAIN_AFFINE: mjtGainValue<1>, mjGAIN_MUSCLE: mjtGainValue<2>, mjGAIN_DCMOTOR: mjtGainValue<3>, mjGAIN_SO3: mjtGainValue<4>, mjGAIN_PID: mjtGainValue<5>, mjGAIN_USER: mjtGainValue<6>};
  mjtGeom: {mjGEOM_PLANE: mjtGeomValue<0>, mjGEOM_HFIELD: mjtGeomValue<1>, mjGEOM_SPHERE: mjtGeomValue<2>, mjGEOM_CAPSULE: mjtGeomValue<3>, mjGEOM_ELLIPSOID: mjtGeomValue<4>, mjGEOM_CYLINDER: mjtGeomValue<5>, mjGEOM_BOX: mjtGeomValue<6>, mjGEOM_MESH: mjtGeomValue<7>, mjGEOM_SDF: mjtGeomValue<8>, mjNGEOMTYPES: mjtGeomValue<9>, mjGEOM_ARROW: mjtGeomValue<100>, mjGEOM_ARROW1: mjtGeomValue<101>, mjGEOM_ARROW2: mjtGeomValue<102>, mjGEOM_LINE: mjtGeomValue<103>, mjGEOM_LINEBOX: mjtGeomValue<104>, mjGEOM_FLEX: mjtGeomValue<105>, mjGEOM_SKIN: mjtGeomValue<106>, mjGEOM_LABEL: mjtGeomValue<107>, mjGEOM_TRIANGLE: mjtGeomValue<108>, mjGEOM_NONE: mjtGeomValue<1001>};
  mjtGeomInertia: {mjINERTIA_VOLUME: mjtGeomInertiaValue<0>, mjINERTIA_SHELL: mjtGeomInertiaValue<1>};
  mjtGridPos: {mjGRID_TOPLEFT: mjtGridPosValue<0>, mjGRID_TOPRIGHT: mjtGridPosValue<1>, mjGRID_BOTTOMLEFT: mjtGridPosValue<2>, mjGRID_BOTTOMRIGHT: mjtGridPosValue<3>, mjGRID_TOP: mjtGridPosValue<4>, mjGRID_BOTTOM: mjtGridPosValue<5>, mjGRID_LEFT: mjtGridPosValue<6>, mjGRID_RIGHT: mjtGridPosValue<7>};
  mjtInertiaFromGeom: {mjINERTIAFROMGEOM_FALSE: mjtInertiaFromGeomValue<0>, mjINERTIAFROMGEOM_TRUE: mjtInertiaFromGeomValue<1>, mjINERTIAFROMGEOM_AUTO: mjtInertiaFromGeomValue<2>};
  mjtIntegrator: {mjINT_EULER: mjtIntegratorValue<0>, mjINT_RK4: mjtIntegratorValue<1>, mjINT_IMPLICIT: mjtIntegratorValue<2>, mjINT_IMPLICITFAST: mjtIntegratorValue<3>};
  mjtItem: {mjITEM_END: mjtItemValue<-2>, mjITEM_SECTION: mjtItemValue<-1>, mjITEM_SEPARATOR: mjtItemValue<0>, mjITEM_STATIC: mjtItemValue<1>, mjITEM_BUTTON: mjtItemValue<2>, mjITEM_CHECKINT: mjtItemValue<3>, mjITEM_CHECKBYTE: mjtItemValue<4>, mjITEM_RADIO: mjtItemValue<5>, mjITEM_RADIOLINE: mjtItemValue<6>, mjITEM_SELECT: mjtItemValue<7>, mjITEM_SLIDERINT: mjtItemValue<8>, mjITEM_SLIDERNUM: mjtItemValue<9>, mjITEM_EDITINT: mjtItemValue<10>, mjITEM_EDITNUM: mjtItemValue<11>, mjITEM_EDITFLOAT: mjtItemValue<12>, mjITEM_EDITTXT: mjtItemValue<13>, mjNITEM: mjtItemValue<14>};
  mjtJacobian: {mjJAC_DENSE: mjtJacobianValue<0>, mjJAC_SPARSE: mjtJacobianValue<1>, mjJAC_AUTO: mjtJacobianValue<2>};
  mjtJoint: {mjJNT_FREE: mjtJointValue<0>, mjJNT_BALL: mjtJointValue<1>, mjJNT_SLIDE: mjtJointValue<2>, mjJNT_HINGE: mjtJointValue<3>};
  mjtLRMode: {mjLRMODE_NONE: mjtLRModeValue<0>, mjLRMODE_MUSCLE: mjtLRModeValue<1>, mjLRMODE_MUSCLEUSER: mjtLRModeValue<2>, mjLRMODE_ALL: mjtLRModeValue<3>};
  mjtLabel: {mjLABEL_NONE: mjtLabelValue<0>, mjLABEL_BODY: mjtLabelValue<1>, mjLABEL_JOINT: mjtLabelValue<2>, mjLABEL_GEOM: mjtLabelValue<3>, mjLABEL_SITE: mjtLabelValue<4>, mjLABEL_CAMERA: mjtLabelValue<5>, mjLABEL_LIGHT: mjtLabelValue<6>, mjLABEL_TENDON: mjtLabelValue<7>, mjLABEL_ACTUATOR: mjtLabelValue<8>, mjLABEL_CONSTRAINT: mjtLabelValue<9>, mjLABEL_FLEX: mjtLabelValue<10>, mjLABEL_SKIN: mjtLabelValue<11>, mjLABEL_SELECTION: mjtLabelValue<12>, mjLABEL_SELPNT: mjtLabelValue<13>, mjLABEL_CONTACTPOINT: mjtLabelValue<14>, mjLABEL_CONTACTFORCE: mjtLabelValue<15>, mjLABEL_ISLAND: mjtLabelValue<16>, mjNLABEL: mjtLabelValue<17>};
  mjtLightType: {mjLIGHT_SPOT: mjtLightTypeValue<0>, mjLIGHT_DIRECTIONAL: mjtLightTypeValue<1>, mjLIGHT_POINT: mjtLightTypeValue<2>, mjLIGHT_IMAGE: mjtLightTypeValue<3>};
  mjtLimited: {mjLIMITED_FALSE: mjtLimitedValue<0>, mjLIMITED_TRUE: mjtLimitedValue<1>, mjLIMITED_AUTO: mjtLimitedValue<2>};
  mjtLogLevel: {mjLOG_DEBUG: mjtLogLevelValue<0>, mjLOG_INFO: mjtLogLevelValue<1>, mjLOG_WARNING: mjtLogLevelValue<2>, mjLOG_ERROR: mjtLogLevelValue<3>};
  mjtLogTopic: {mjTOPIC_NONE: mjtLogTopicValue<0>, mjTOPIC_TIME_STP: mjtLogTopicValue<1>, mjTOPIC_TIME_CMP: mjtLogTopicValue<2>, mjTOPIC_SLEEP: mjtLogTopicValue<3>, mjNTOPIC: mjtLogTopicValue<3>};
  mjtMark: {mjMARK_NONE: mjtMarkValue<0>, mjMARK_EDGE: mjtMarkValue<1>, mjMARK_CROSS: mjtMarkValue<2>, mjMARK_RANDOM: mjtMarkValue<3>};
  mjtMeshBuiltin: {mjMESH_BUILTIN_NONE: mjtMeshBuiltinValue<0>, mjMESH_BUILTIN_SPHERE: mjtMeshBuiltinValue<1>, mjMESH_BUILTIN_HEMISPHERE: mjtMeshBuiltinValue<2>, mjMESH_BUILTIN_CONE: mjtMeshBuiltinValue<3>, mjMESH_BUILTIN_SUPERSPHERE: mjtMeshBuiltinValue<4>, mjMESH_BUILTIN_SUPERTORUS: mjtMeshBuiltinValue<5>, mjMESH_BUILTIN_WEDGE: mjtMeshBuiltinValue<6>, mjMESH_BUILTIN_PLATE: mjtMeshBuiltinValue<7>};
  mjtMeshInertia: {mjMESH_INERTIA_CONVEX: mjtMeshInertiaValue<0>, mjMESH_INERTIA_EXACT: mjtMeshInertiaValue<1>, mjMESH_INERTIA_LEGACY: mjtMeshInertiaValue<2>, mjMESH_INERTIA_SHELL: mjtMeshInertiaValue<3>};
  mjtMouse: {mjMOUSE_NONE: mjtMouseValue<0>, mjMOUSE_ROTATE_V: mjtMouseValue<1>, mjMOUSE_ROTATE_H: mjtMouseValue<2>, mjMOUSE_MOVE_V: mjtMouseValue<3>, mjMOUSE_MOVE_H: mjtMouseValue<4>, mjMOUSE_ZOOM: mjtMouseValue<5>, mjMOUSE_MOVE_V_REL: mjtMouseValue<6>, mjMOUSE_MOVE_H_REL: mjtMouseValue<7>, mjMOUSE_TURN_V: mjtMouseValue<8>, mjMOUSE_TURN_H: mjtMouseValue<9>};
  mjtObj: {mjOBJ_UNKNOWN: mjtObjValue<0>, mjOBJ_BODY: mjtObjValue<1>, mjOBJ_XBODY: mjtObjValue<2>, mjOBJ_JOINT: mjtObjValue<3>, mjOBJ_DOF: mjtObjValue<4>, mjOBJ_GEOM: mjtObjValue<5>, mjOBJ_SITE: mjtObjValue<6>, mjOBJ_CAMERA: mjtObjValue<7>, mjOBJ_LIGHT: mjtObjValue<8>, mjOBJ_FLEX: mjtObjValue<9>, mjOBJ_MESH: mjtObjValue<10>, mjOBJ_SKIN: mjtObjValue<11>, mjOBJ_HFIELD: mjtObjValue<12>, mjOBJ_TEXTURE: mjtObjValue<13>, mjOBJ_MATERIAL: mjtObjValue<14>, mjOBJ_PAIR: mjtObjValue<15>, mjOBJ_EXCLUDE: mjtObjValue<16>, mjOBJ_EQUALITY: mjtObjValue<17>, mjOBJ_TENDON: mjtObjValue<18>, mjOBJ_ACTUATOR: mjtObjValue<19>, mjOBJ_SENSOR: mjtObjValue<20>, mjOBJ_NUMERIC: mjtObjValue<21>, mjOBJ_TEXT: mjtObjValue<22>, mjOBJ_TUPLE: mjtObjValue<23>, mjOBJ_KEY: mjtObjValue<24>, mjOBJ_PLUGIN: mjtObjValue<25>, mjNOBJECT: mjtObjValue<26>, mjOBJ_FRAME: mjtObjValue<100>, mjOBJ_DEFAULT: mjtObjValue<101>, mjOBJ_MODEL: mjtObjValue<102>};
  mjtOrientation: {mjORIENTATION_QUAT: mjtOrientationValue<0>, mjORIENTATION_AXISANGLE: mjtOrientationValue<1>, mjORIENTATION_XYAXES: mjtOrientationValue<2>, mjORIENTATION_ZAXIS: mjtOrientationValue<3>, mjORIENTATION_EULER: mjtOrientationValue<4>};
  mjtPertBit: {mjPERT_TRANSLATE: mjtPertBitValue<1>, mjPERT_ROTATE: mjtPertBitValue<2>};
  mjtPluginCapabilityBit: {mjPLUGIN_ACTUATOR: mjtPluginCapabilityBitValue<1>, mjPLUGIN_SENSOR: mjtPluginCapabilityBitValue<2>, mjPLUGIN_PASSIVE: mjtPluginCapabilityBitValue<4>, mjPLUGIN_SDF: mjtPluginCapabilityBitValue<8>};
  mjtProjection: {mjPROJ_PERSPECTIVE: mjtProjectionValue<0>, mjPROJ_ORTHOGRAPHIC: mjtProjectionValue<1>};
  mjtRayDataField: {mjRAYDATA_DIST: mjtRayDataFieldValue<0>, mjRAYDATA_DIR: mjtRayDataFieldValue<1>, mjRAYDATA_ORIGIN: mjtRayDataFieldValue<2>, mjRAYDATA_POINT: mjtRayDataFieldValue<3>, mjRAYDATA_NORMAL: mjtRayDataFieldValue<4>, mjRAYDATA_DEPTH: mjtRayDataFieldValue<5>, mjNRAYDATA: mjtRayDataFieldValue<6>};
  mjtRndFlag: {mjRND_SHADOW: mjtRndFlagValue<0>, mjRND_WIREFRAME: mjtRndFlagValue<1>, mjRND_REFLECTION: mjtRndFlagValue<2>, mjRND_ADDITIVE: mjtRndFlagValue<3>, mjRND_SKYBOX: mjtRndFlagValue<4>, mjRND_FOG: mjtRndFlagValue<5>, mjRND_HAZE: mjtRndFlagValue<6>, mjRND_DEPTH: mjtRndFlagValue<7>, mjRND_SEGMENT: mjtRndFlagValue<8>, mjRND_IDCOLOR: mjtRndFlagValue<9>, mjRND_CULL_FACE: mjtRndFlagValue<10>, mjNRNDFLAG: mjtRndFlagValue<11>};
  mjtSDFType: {mjSDFTYPE_SINGLE: mjtSDFTypeValue<0>, mjSDFTYPE_INTERSECTION: mjtSDFTypeValue<1>, mjSDFTYPE_MIDSURFACE: mjtSDFTypeValue<2>, mjSDFTYPE_COLLISION: mjtSDFTypeValue<3>};
  mjtSameFrame: {mjSAMEFRAME_NONE: mjtSameFrameValue<0>, mjSAMEFRAME_BODY: mjtSameFrameValue<1>, mjSAMEFRAME_INERTIA: mjtSameFrameValue<2>, mjSAMEFRAME_BODYROT: mjtSameFrameValue<3>, mjSAMEFRAME_INERTIAROT: mjtSameFrameValue<4>};
  mjtSection: {mjSECT_CLOSED: mjtSectionValue<0>, mjSECT_OPEN: mjtSectionValue<1>, mjSECT_FIXED: mjtSectionValue<2>};
  mjtSensor: {mjSENS_TOUCH: mjtSensorValue<0>, mjSENS_ACCELEROMETER: mjtSensorValue<1>, mjSENS_VELOCIMETER: mjtSensorValue<2>, mjSENS_GYRO: mjtSensorValue<3>, mjSENS_FORCE: mjtSensorValue<4>, mjSENS_TORQUE: mjtSensorValue<5>, mjSENS_MAGNETOMETER: mjtSensorValue<6>, mjSENS_RANGEFINDER: mjtSensorValue<7>, mjSENS_CAMPROJECTION: mjtSensorValue<8>, mjSENS_JOINTPOS: mjtSensorValue<9>, mjSENS_JOINTVEL: mjtSensorValue<10>, mjSENS_TENDONPOS: mjtSensorValue<11>, mjSENS_TENDONVEL: mjtSensorValue<12>, mjSENS_ACTUATORPOS: mjtSensorValue<13>, mjSENS_ACTUATORVEL: mjtSensorValue<14>, mjSENS_ACTUATORFRC: mjtSensorValue<15>, mjSENS_JOINTACTFRC: mjtSensorValue<16>, mjSENS_TENDONACTFRC: mjtSensorValue<17>, mjSENS_BALLQUAT: mjtSensorValue<18>, mjSENS_BALLANGVEL: mjtSensorValue<19>, mjSENS_JOINTLIMITPOS: mjtSensorValue<20>, mjSENS_JOINTLIMITVEL: mjtSensorValue<21>, mjSENS_JOINTLIMITFRC: mjtSensorValue<22>, mjSENS_TENDONLIMITPOS: mjtSensorValue<23>, mjSENS_TENDONLIMITVEL: mjtSensorValue<24>, mjSENS_TENDONLIMITFRC: mjtSensorValue<25>, mjSENS_FRAMEPOS: mjtSensorValue<26>, mjSENS_FRAMEQUAT: mjtSensorValue<27>, mjSENS_FRAMEXAXIS: mjtSensorValue<28>, mjSENS_FRAMEYAXIS: mjtSensorValue<29>, mjSENS_FRAMEZAXIS: mjtSensorValue<30>, mjSENS_FRAMELINVEL: mjtSensorValue<31>, mjSENS_FRAMEANGVEL: mjtSensorValue<32>, mjSENS_FRAMELINACC: mjtSensorValue<33>, mjSENS_FRAMEANGACC: mjtSensorValue<34>, mjSENS_SUBTREECOM: mjtSensorValue<35>, mjSENS_SUBTREELINVEL: mjtSensorValue<36>, mjSENS_SUBTREEANGMOM: mjtSensorValue<37>, mjSENS_INSIDESITE: mjtSensorValue<38>, mjSENS_GEOMDIST: mjtSensorValue<39>, mjSENS_GEOMNORMAL: mjtSensorValue<40>, mjSENS_GEOMFROMTO: mjtSensorValue<41>, mjSENS_CONTACT: mjtSensorValue<42>, mjSENS_E_POTENTIAL: mjtSensorValue<43>, mjSENS_E_KINETIC: mjtSensorValue<44>, mjSENS_CLOCK: mjtSensorValue<45>, mjSENS_TACTILE: mjtSensorValue<46>, mjSENS_PLUGIN: mjtSensorValue<47>, mjSENS_USER: mjtSensorValue<48>};
  mjtSleepPolicy: {mjSLEEP_AUTO: mjtSleepPolicyValue<0>, mjSLEEP_AUTO_NEVER: mjtSleepPolicyValue<1>, mjSLEEP_AUTO_ALLOWED: mjtSleepPolicyValue<2>, mjSLEEP_NEVER: mjtSleepPolicyValue<3>, mjSLEEP_ALLOWED: mjtSleepPolicyValue<4>, mjSLEEP_INIT: mjtSleepPolicyValue<5>};
  mjtSleepState: {mjS_STATIC: mjtSleepStateValue<-1>, mjS_ASLEEP: mjtSleepStateValue<0>, mjS_AWAKE: mjtSleepStateValue<1>};
  mjtSolver: {mjSOL_PGS: mjtSolverValue<0>, mjSOL_CG: mjtSolverValue<1>, mjSOL_NEWTON: mjtSolverValue<2>};
  mjtStage: {mjSTAGE_NONE: mjtStageValue<0>, mjSTAGE_POS: mjtStageValue<1>, mjSTAGE_VEL: mjtStageValue<2>, mjSTAGE_ACC: mjtStageValue<3>};
  mjtState: {mjSTATE_TIME: mjtStateValue<1>, mjSTATE_QPOS: mjtStateValue<2>, mjSTATE_QVEL: mjtStateValue<4>, mjSTATE_ACT: mjtStateValue<8>, mjSTATE_HISTORY: mjtStateValue<16>, mjSTATE_WARMSTART: mjtStateValue<32>, mjSTATE_CTRL: mjtStateValue<64>, mjSTATE_QFRC_APPLIED: mjtStateValue<128>, mjSTATE_XFRC_APPLIED: mjtStateValue<256>, mjSTATE_EQ_ACTIVE: mjtStateValue<512>, mjSTATE_MOCAP_POS: mjtStateValue<1024>, mjSTATE_MOCAP_QUAT: mjtStateValue<2048>, mjSTATE_USERDATA: mjtStateValue<4096>, mjSTATE_PLUGIN: mjtStateValue<8192>, mjNSTATE: mjtStateValue<14>, mjSTATE_PHYSICS: mjtStateValue<30>, mjSTATE_FULLPHYSICS: mjtStateValue<8223>, mjSTATE_USER: mjtStateValue<8128>, mjSTATE_INTEGRATION: mjtStateValue<16383>};
  mjtStereo: {mjSTEREO_NONE: mjtStereoValue<0>, mjSTEREO_QUADBUFFERED: mjtStereoValue<1>, mjSTEREO_SIDEBYSIDE: mjtStereoValue<2>};
  mjtTexture: {mjTEXTURE_2D: mjtTextureValue<0>, mjTEXTURE_CUBE: mjtTextureValue<1>, mjTEXTURE_SKYBOX: mjtTextureValue<2>};
  mjtTextureRole: {mjTEXROLE_USER: mjtTextureRoleValue<0>, mjTEXROLE_RGB: mjtTextureRoleValue<1>, mjTEXROLE_OCCLUSION: mjtTextureRoleValue<2>, mjTEXROLE_ROUGHNESS: mjtTextureRoleValue<3>, mjTEXROLE_METALLIC: mjtTextureRoleValue<4>, mjTEXROLE_NORMAL: mjtTextureRoleValue<5>, mjTEXROLE_OPACITY: mjtTextureRoleValue<6>, mjTEXROLE_EMISSIVE: mjtTextureRoleValue<7>, mjTEXROLE_RGBA: mjtTextureRoleValue<8>, mjTEXROLE_ORM: mjtTextureRoleValue<9>, mjNTEXROLE: mjtTextureRoleValue<10>};
  mjtTimer: {mjTIMER_STEP: mjtTimerValue<0>, mjTIMER_FORWARD: mjtTimerValue<1>, mjTIMER_INVERSE: mjtTimerValue<2>, mjTIMER_POSITION: mjtTimerValue<3>, mjTIMER_VELOCITY: mjtTimerValue<4>, mjTIMER_ACTUATION: mjtTimerValue<5>, mjTIMER_CONSTRAINT: mjtTimerValue<6>, mjTIMER_ADVANCE: mjtTimerValue<7>, mjTIMER_POS_KINEMATICS: mjtTimerValue<8>, mjTIMER_POS_INERTIA: mjtTimerValue<9>, mjTIMER_POS_COLLISION: mjtTimerValue<10>, mjTIMER_POS_MAKE: mjtTimerValue<11>, mjTIMER_POS_PROJECT: mjtTimerValue<12>, mjTIMER_COL_BROAD: mjtTimerValue<13>, mjTIMER_COL_NARROW: mjtTimerValue<14>, mjNTIMER: mjtTimerValue<15>};
  mjtTrn: {mjTRN_JOINT: mjtTrnValue<0>, mjTRN_JOINTINPARENT: mjtTrnValue<1>, mjTRN_SLIDERCRANK: mjtTrnValue<2>, mjTRN_TENDON: mjtTrnValue<3>, mjTRN_SITE: mjtTrnValue<4>, mjTRN_BODY: mjtTrnValue<5>, mjTRN_SO3: mjtTrnValue<6>, mjTRN_UNDEFINED: mjtTrnValue<1000>};
  mjtVisFlag: {mjVIS_CONVEXHULL: mjtVisFlagValue<0>, mjVIS_TEXTURE: mjtVisFlagValue<1>, mjVIS_JOINT: mjtVisFlagValue<2>, mjVIS_CAMERA: mjtVisFlagValue<3>, mjVIS_ACTUATOR: mjtVisFlagValue<4>, mjVIS_ACTIVATION: mjtVisFlagValue<5>, mjVIS_LIGHT: mjtVisFlagValue<6>, mjVIS_TENDON: mjtVisFlagValue<7>, mjVIS_RANGEFINDER: mjtVisFlagValue<8>, mjVIS_CONSTRAINT: mjtVisFlagValue<9>, mjVIS_INERTIA: mjtVisFlagValue<10>, mjVIS_SCLINERTIA: mjtVisFlagValue<11>, mjVIS_PERTFORCE: mjtVisFlagValue<12>, mjVIS_PERTOBJ: mjtVisFlagValue<13>, mjVIS_CONTACTPOINT: mjtVisFlagValue<14>, mjVIS_ISLAND: mjtVisFlagValue<15>, mjVIS_CONTACTFORCE: mjtVisFlagValue<16>, mjVIS_CONTACTSPLIT: mjtVisFlagValue<17>, mjVIS_TRANSPARENT: mjtVisFlagValue<18>, mjVIS_AUTOCONNECT: mjtVisFlagValue<19>, mjVIS_COM: mjtVisFlagValue<20>, mjVIS_SELECT: mjtVisFlagValue<21>, mjVIS_STATIC: mjtVisFlagValue<22>, mjVIS_SKIN: mjtVisFlagValue<23>, mjVIS_FLEXVERT: mjtVisFlagValue<24>, mjVIS_FLEXEDGE: mjtVisFlagValue<25>, mjVIS_FLEXFACE: mjtVisFlagValue<26>, mjVIS_FLEXSKIN: mjtVisFlagValue<27>, mjVIS_BODYBVH: mjtVisFlagValue<28>, mjVIS_MESHBVH: mjtVisFlagValue<29>, mjVIS_SDFITER: mjtVisFlagValue<30>, mjNVISFLAG: mjtVisFlagValue<31>};
  mjtWarning: {mjWARN_INERTIA: mjtWarningValue<0>, mjWARN_CONTACTFULL: mjtWarningValue<1>, mjWARN_CNSTRFULL: mjtWarningValue<2>, mjWARN_BADQPOS: mjtWarningValue<3>, mjWARN_BADQVEL: mjtWarningValue<4>, mjWARN_BADQACC: mjtWarningValue<5>, mjWARN_BADCTRL: mjtWarningValue<6>, mjNWARNING: mjtWarningValue<7>};
  mjtWrap: {mjWRAP_NONE: mjtWrapValue<0>, mjWRAP_JOINT: mjtWrapValue<1>, mjWRAP_PULLEY: mjtWrapValue<2>, mjWRAP_SITE: mjtWrapValue<3>, mjWRAP_SPHERE: mjtWrapValue<4>, mjWRAP_CYLINDER: mjtWrapValue<5>};
  MjModelActuatorAccessor: {};
  MjModelBodyAccessor: {};
  MjModelCameraAccessor: {};
  MjModelEqualityAccessor: {};
  MjModelExcludeAccessor: {};
  MjModelGeomAccessor: {};
  MjModelHfieldAccessor: {};
  MjModelJointAccessor: {};
  MjModelLightAccessor: {};
  MjModelMaterialAccessor: {};
  MjModelMeshAccessor: {};
  MjModelNumericAccessor: {};
  MjModelPairAccessor: {};
  MjModelSensorAccessor: {};
  MjModelSiteAccessor: {};
  MjModelSkinAccessor: {};
  MjModelTendonAccessor: {};
  MjModelTextureAccessor: {};
  MjModelTupleAccessor: {};
  MjModelKeyframeAccessor: {};
  MjDataActuatorAccessor: {};
  MjDataBodyAccessor: {};
  MjDataCameraAccessor: {};
  MjDataGeomAccessor: {};
  MjDataJointAccessor: {};
  MjDataLightAccessor: {};
  MjDataSensorAccessor: {};
  MjDataSiteAccessor: {};
  MjDataTendonAccessor: {};
  MjContact: {
    new(): MjContact;
  };
  MjData: {
    new(_0: MjModel, _1: MjData): MjData;
    new(_0: MjModel | null): MjData;
  };
  MjLROpt: {
    new(): MjLROpt;
  };
  MjLogConfig: {
    new(): MjLogConfig;
  };
  MjLogMessage: {
    new(): MjLogMessage;
  };
  MjModel: {
    new(_0: MjModel): MjModel;
    mj_loadXML(_0: EmbindString): MjModel;
    mj_loadXML(_0: EmbindString, _1: MjVFS): MjModel;
    mj_loadModel(_0: EmbindString, _1: MjVFS): MjModel;
    from_binary_path(_0: EmbindString, _1: MjVFS): MjModel;
    from_xml_string(_0: EmbindString): MjModel;
    from_xml_string(_0: EmbindString, _1: MjVFS): MjModel;
    from_xml_path(_0: EmbindString): MjModel;
    from_xml_path(_0: EmbindString, _1: MjVFS): MjModel;
  };
  MjOption: {
    new(): MjOption;
  };
  MjPreContact: {
    new(): MjPreContact;
  };
  MjSolverStat: {
    new(): MjSolverStat;
  };
  MjSpec: {
    new(_0: MjSpec): MjSpec;
  };
  MjStatistic: {
    new(): MjStatistic;
  };
  MjTimerStat: {
    new(): MjTimerStat;
  };
  MjVisual: {
    new(): MjVisual;
  };
  MjVisualGlobal: {
    new(): MjVisualGlobal;
  };
  MjVisualHeadlight: {
    new(): MjVisualHeadlight;
  };
  MjVisualMap: {
    new(): MjVisualMap;
  };
  MjVisualQuality: {
    new(): MjVisualQuality;
  };
  MjVisualRgba: {
    new(): MjVisualRgba;
  };
  MjVisualScale: {
    new(): MjVisualScale;
  };
  MjWarningStat: {
    new(): MjWarningStat;
  };
  MjsActuator: {};
  MjsAuthored: {};
  MjsBody: {};
  MjsCamera: {};
  MjsCompiler: {};
  MjsDefault: {};
  MjsElement: {};
  MjsEquality: {};
  MjsExclude: {};
  MjsFlex: {};
  MjsFrame: {};
  MjsGeom: {};
  MjsHField: {};
  MjsJoint: {};
  MjsKey: {};
  MjsLight: {};
  MjsMaterial: {};
  MjsMesh: {};
  MjsNumeric: {};
  MjsOrientation: {};
  MjsPair: {};
  MjsPlugin: {};
  MjsSensor: {};
  MjsSite: {};
  MjsSkin: {};
  MjsTendon: {};
  MjsText: {};
  MjsTexture: {};
  MjsTuple: {};
  MjsWrap: {};
  MjvCamera: {
    new(): MjvCamera;
  };
  MjvFigure: {
    new(): MjvFigure;
  };
  MjvGLCamera: {
    new(): MjvGLCamera;
  };
  MjvGeom: {
    new(): MjvGeom;
  };
  MjvLight: {
    new(): MjvLight;
  };
  MjvOption: {
    new(): MjvOption;
  };
  MjvPerturb: {
    new(): MjvPerturb;
  };
  MjvScene: {
    new(): MjvScene;
    new(_0: MjModel | null, _1: number): MjvScene;
  };
  MjVFS: {
    new(): MjVFS;
  };
  mjs_addActuator(_0: MjSpec, _1: MjsDefault): MjsActuator | undefined;
  mjs_addBody(_0: MjsBody, _1: MjsDefault): MjsBody | undefined;
  mjs_addCamera(_0: MjsBody, _1: MjsDefault): MjsCamera | undefined;
  mjs_addEquality(_0: MjSpec, _1: MjsDefault): MjsEquality | undefined;
  mjs_addExclude(_0: MjSpec): MjsExclude | undefined;
  mjs_addFlex(_0: MjSpec): MjsFlex | undefined;
  mjs_addFrame(_0: MjsBody, _1: MjsFrame): MjsFrame | undefined;
  mjs_addFreeJoint(_0: MjsBody): MjsJoint | undefined;
  mjs_addGeom(_0: MjsBody, _1: MjsDefault): MjsGeom | undefined;
  mjs_addHField(_0: MjSpec): MjsHField | undefined;
  mjs_addJoint(_0: MjsBody, _1: MjsDefault): MjsJoint | undefined;
  mjs_addKey(_0: MjSpec): MjsKey | undefined;
  mjs_addLight(_0: MjsBody, _1: MjsDefault): MjsLight | undefined;
  mjs_addMaterial(_0: MjSpec, _1: MjsDefault): MjsMaterial | undefined;
  mjs_addMesh(_0: MjSpec, _1: MjsDefault): MjsMesh | undefined;
  mjs_addNumeric(_0: MjSpec): MjsNumeric | undefined;
  mjs_addPair(_0: MjSpec, _1: MjsDefault): MjsPair | undefined;
  mjs_addPlugin(_0: MjSpec): MjsPlugin | undefined;
  mjs_addSensor(_0: MjSpec): MjsSensor | undefined;
  mjs_addSite(_0: MjsBody, _1: MjsDefault): MjsSite | undefined;
  mjs_addSkin(_0: MjSpec): MjsSkin | undefined;
  mjs_addTendon(_0: MjSpec, _1: MjsDefault): MjsTendon | undefined;
  mjs_addText(_0: MjSpec): MjsText | undefined;
  mjs_addTexture(_0: MjSpec): MjsTexture | undefined;
  mjs_addTuple(_0: MjSpec): MjsTuple | undefined;
  mjs_asActuator(_0: MjsElement): MjsActuator | undefined;
  mjs_asBody(_0: MjsElement): MjsBody | undefined;
  mjs_asCamera(_0: MjsElement): MjsCamera | undefined;
  mjs_asEquality(_0: MjsElement): MjsEquality | undefined;
  mjs_asExclude(_0: MjsElement): MjsExclude | undefined;
  mjs_asFlex(_0: MjsElement): MjsFlex | undefined;
  mjs_asFrame(_0: MjsElement): MjsFrame | undefined;
  mjs_asGeom(_0: MjsElement): MjsGeom | undefined;
  mjs_asHField(_0: MjsElement): MjsHField | undefined;
  mjs_asJoint(_0: MjsElement): MjsJoint | undefined;
  mjs_asKey(_0: MjsElement): MjsKey | undefined;
  mjs_asLight(_0: MjsElement): MjsLight | undefined;
  mjs_asMaterial(_0: MjsElement): MjsMaterial | undefined;
  mjs_asMesh(_0: MjsElement): MjsMesh | undefined;
  mjs_asNumeric(_0: MjsElement): MjsNumeric | undefined;
  mjs_asPair(_0: MjsElement): MjsPair | undefined;
  mjs_asPlugin(_0: MjsElement): MjsPlugin | undefined;
  mjs_asSensor(_0: MjsElement): MjsSensor | undefined;
  mjs_asSite(_0: MjsElement): MjsSite | undefined;
  mjs_asSkin(_0: MjsElement): MjsSkin | undefined;
  mjs_asTendon(_0: MjsElement): MjsTendon | undefined;
  mjs_asText(_0: MjsElement): MjsText | undefined;
  mjs_asTexture(_0: MjsElement): MjsTexture | undefined;
  mjs_asTuple(_0: MjsElement): MjsTuple | undefined;
  mjs_firstElement(_0: MjSpec, _1: mjtObj): MjsElement | undefined;
  mjs_getCompiler(_0: MjsElement): MjsCompiler | undefined;
  mjs_getDefault(_0: MjsElement): MjsDefault | undefined;
  mjs_getFrame(_0: MjsElement): MjsFrame | undefined;
  mjs_getOriginSpec(_0: MjsElement): MjSpec | undefined;
  mjs_getParent(_0: MjsElement): MjsBody | undefined;
  mjs_getSpec(_0: MjsElement): MjSpec | undefined;
  mjs_getSpecDefault(_0: MjSpec): MjsDefault | undefined;
  mjs_getWrapSideSite(_0: MjsWrap): MjsSite | undefined;
  mjs_getWrapTarget(_0: MjsWrap): MjsElement | undefined;
  mjs_nextElement(_0: MjSpec, _1: MjsElement): MjsElement | undefined;
  mju_getLogConfig(): MjLogConfig;
  mjv_camera2GLCamera(_0: MjModel, _1: MjData, _2: MjvCamera): MjvGLCamera;
  mj_compile(_0: MjSpec): MjModel;
  mj_compile(_0: MjSpec, _1: MjVFS): MjModel;
  FloatBuffer: {
    new(_0: number): FloatBuffer;
    FromArray(_0: any): FloatBuffer;
  };
  DoubleBuffer: {
    new(_0: number): DoubleBuffer;
    FromArray(_0: any): DoubleBuffer;
  };
  IntBuffer: {
    new(_0: number): IntBuffer;
    FromArray(_0: any): IntBuffer;
  };
  Uint8Buffer: {
    new(_0: number): Uint8Buffer;
    FromArray(_0: any): Uint8Buffer;
  };
  mjStringVec: {
    new(): mjStringVec;
  };
  mjStringVecVec: {
    new(): mjStringVecVec;
  };
  mjIntVec: {
    new(): mjIntVec;
  };
  mjIntVecVec: {
    new(): mjIntVecVec;
  };
  mjFloatVec: {
    new(): mjFloatVec;
  };
  mjFloatVecVec: {
    new(): mjFloatVecVec;
  };
  mjDoubleVec: {
    new(): mjDoubleVec;
  };
  mjByteVec: {
    new(): mjByteVec;
  };
  MjSolverStatVec: {
    new(): MjSolverStatVec;
  };
  MjTimerStatVec: {
    new(): MjTimerStatVec;
  };
  MjWarningStatVec: {
    new(): MjWarningStatVec;
  };
  MjContactVec: {
    new(): MjContactVec;
  };
  MjvLightVec: {
    new(): MjvLightVec;
  };
  MjvGLCameraVec: {
    new(): MjvGLCameraVec;
  };
  MjvGeomVec: {
    new(): MjvGeomVec;
  };
  mjs_addDefault(_0: MjSpec, _1: string, _2: MjsDefault): MjsDefault | undefined;
  mjs_attach(_0: MjsElement, _1: MjsElement, _2: string, _3: string): MjsElement | undefined;
  mjs_findBody(_0: MjSpec, _1: string): MjsBody | undefined;
  mjs_findChild(_0: MjsBody, _1: string): MjsBody | undefined;
  mjs_findDefault(_0: MjSpec, _1: string): MjsDefault | undefined;
  mjs_findElement(_0: MjSpec, _1: mjtObj, _2: string): MjsElement | undefined;
  mjs_findFrame(_0: MjSpec, _1: string): MjsFrame | undefined;
  mjs_findSpec(_0: MjSpec, _1: string): MjSpec | undefined;
  mjs_wrapGeom(_0: MjsTendon, _1: string, _2: string): MjsWrap | undefined;
  mjs_wrapSite(_0: MjsTendon, _1: string): MjsWrap | undefined;
  mj_Euler(_0: MjModel, _1: MjData): void;
  mj_camlight(_0: MjModel, _1: MjData): void;
  mj_checkAcc(_0: MjModel, _1: MjData): void;
  mj_checkPos(_0: MjModel, _1: MjData): void;
  mj_checkVel(_0: MjModel, _1: MjData): void;
  mj_collision(_0: MjModel, _1: MjData): void;
  mj_comPos(_0: MjModel, _1: MjData): void;
  mj_comVel(_0: MjModel, _1: MjData): void;
  mj_compareFwdInv(_0: MjModel, _1: MjData): void;
  mj_crb(_0: MjModel, _1: MjData): void;
  mj_defaultLROpt(_0: MjLROpt): void;
  mj_defaultOption(_0: MjOption): void;
  mj_defaultVisual(_0: MjVisual): void;
  mj_energyPos(_0: MjModel, _1: MjData): void;
  mj_energyVel(_0: MjModel, _1: MjData): void;
  mj_factorM(_0: MjModel, _1: MjData): void;
  mj_flex(_0: MjModel, _1: MjData): void;
  mj_forward(_0: MjModel, _1: MjData): void;
  mj_fwdAcceleration(_0: MjModel, _1: MjData): void;
  mj_fwdActuation(_0: MjModel, _1: MjData): void;
  mj_fwdConstraint(_0: MjModel, _1: MjData): void;
  mj_fwdKinematics(_0: MjModel, _1: MjData): void;
  mj_fwdPosition(_0: MjModel, _1: MjData): void;
  mj_fwdVelocity(_0: MjModel, _1: MjData): void;
  mj_implicit(_0: MjModel, _1: MjData): void;
  mj_invConstraint(_0: MjModel, _1: MjData): void;
  mj_invPosition(_0: MjModel, _1: MjData): void;
  mj_invVelocity(_0: MjModel, _1: MjData): void;
  mj_inverse(_0: MjModel, _1: MjData): void;
  mj_island(_0: MjModel, _1: MjData): void;
  mj_kinematics(_0: MjModel, _1: MjData): void;
  mj_makeConstraint(_0: MjModel, _1: MjData): void;
  mj_makeM(_0: MjModel, _1: MjData): void;
  mj_passive(_0: MjModel, _1: MjData): void;
  mj_printData(_0: MjModel, _1: MjData, _2: string): void;
  mj_printFormattedData(_0: MjModel, _1: MjData, _2: string, _3: string): void;
  mj_printFormattedModel(_0: MjModel, _1: string, _2: string): void;
  mj_printFormattedScene(_0: MjvScene, _1: string, _2: string): void;
  mj_printModel(_0: MjModel, _1: string): void;
  mj_printScene(_0: MjvScene, _1: string): void;
  mj_projectConstraint(_0: MjModel, _1: MjData): void;
  mj_referenceConstraint(_0: MjModel, _1: MjData): void;
  mj_resetCallbacks(): void;
  mj_resetCtrl(_0: MjModel, _1: MjData): void;
  mj_resetData(_0: MjModel, _1: MjData): void;
  mj_rnePostConstraint(_0: MjModel, _1: MjData): void;
  mj_sensorAcc(_0: MjModel, _1: MjData): void;
  mj_sensorPos(_0: MjModel, _1: MjData): void;
  mj_sensorVel(_0: MjModel, _1: MjData): void;
  mj_setConst(_0: MjModel, _1: MjData): void;
  mj_step(_0: MjModel, _1: MjData): void;
  mj_step1(_0: MjModel, _1: MjData): void;
  mj_step2(_0: MjModel, _1: MjData): void;
  mj_subtreeVel(_0: MjModel, _1: MjData): void;
  mj_tendon(_0: MjModel, _1: MjData): void;
  mj_transmission(_0: MjModel, _1: MjData): void;
  mjs_defaultActuator(_0: MjsActuator): void;
  mjs_defaultBody(_0: MjsBody): void;
  mjs_defaultCamera(_0: MjsCamera): void;
  mjs_defaultEquality(_0: MjsEquality): void;
  mjs_defaultFlex(_0: MjsFlex): void;
  mjs_defaultFrame(_0: MjsFrame): void;
  mjs_defaultGeom(_0: MjsGeom): void;
  mjs_defaultHField(_0: MjsHField): void;
  mjs_defaultJoint(_0: MjsJoint): void;
  mjs_defaultKey(_0: MjsKey): void;
  mjs_defaultLight(_0: MjsLight): void;
  mjs_defaultMaterial(_0: MjsMaterial): void;
  mjs_defaultMesh(_0: MjsMesh): void;
  mjs_defaultNumeric(_0: MjsNumeric): void;
  mjs_defaultOrientation(_0: MjsOrientation): void;
  mjs_defaultPair(_0: MjsPair): void;
  mjs_defaultPlugin(_0: MjsPlugin): void;
  mjs_defaultSensor(_0: MjsSensor): void;
  mjs_defaultSite(_0: MjsSite): void;
  mjs_defaultSkin(_0: MjsSkin): void;
  mjs_defaultSpec(_0: MjSpec): void;
  mjs_defaultTendon(_0: MjsTendon): void;
  mjs_defaultText(_0: MjsText): void;
  mjs_defaultTexture(_0: MjsTexture): void;
  mjs_defaultTuple(_0: MjsTuple): void;
  mjs_deleteUserValue(_0: MjsElement, _1: string): void;
  mjs_setDefault(_0: MjsElement, _1: MjsDefault): void;
  mju_message(_0: MjLogMessage): void;
  mju_printMatSparse(_0: number[], _1: number[], _2: number[], _3: number[]): void;
  mju_setLogConfig(_0: MjLogConfig): void;
  mju_writeLog(_0: string, _1: string): void;
  mjv_applyPerturbForce(_0: MjModel, _1: MjData, _2: MjvPerturb): void;
  mjv_defaultCamera(_0: MjvCamera): void;
  mjv_defaultFigure(_0: MjvFigure): void;
  mjv_defaultFreeCamera(_0: MjModel, _1: MjvCamera): void;
  mjv_defaultOption(_0: MjvOption): void;
  mjv_defaultPerturb(_0: MjvPerturb): void;
  mjv_initPerturb(_0: MjModel, _1: MjData, _2: MjvScene, _3: MjvPerturb): void;
  mjv_makeLights(_0: MjModel, _1: MjData, _2: MjvScene): void;
  mjv_updateCamera(_0: MjModel, _1: MjData, _2: MjvCamera, _3: MjvScene): void;
  mjv_updateSkin(_0: MjModel, _1: MjData, _2: MjvScene): void;
  error(_0: string): void;
  mj_resetDataDebug(_0: MjModel, _1: MjData, _2: number): void;
  mj_RungeKutta(_0: MjModel, _1: MjData, _2: number): void;
  mj_addContact(_0: MjModel, _1: MjData, _2: MjContact): number;
  mj_copyBack(_0: MjSpec, _1: MjModel): number;
  mj_copyState(_0: MjModel, _1: MjData, _2: MjData, _3: number): void;
  mj_forwardSkip(_0: MjModel, _1: MjData, _2: number, _3: number): void;
  mj_initCtrlHistory(_0: MjModel, _1: MjData, _2: number, _3: number[], _4: number[]): void;
  mj_inverseSkip(_0: MjModel, _1: MjData, _2: number, _3: number): void;
  mj_isDual(_0: MjModel): number;
  mj_isPyramidal(_0: MjModel): number;
  mj_isSparse(_0: MjModel): number;
  mj_maxContact(_0: MjModel, _1: number, _2: number, _3: number): number;
  mj_name2id(_0: MjModel, _1: number, _2: string): number;
  mj_resetDataKeyframe(_0: MjModel, _1: MjData, _2: number): void;
  mj_setKeyframe(_0: MjModel, _1: MjData, _2: number): void;
  mj_setState(_0: MjModel, _1: MjData, _2: number[], _3: number): void;
  mj_stateSize(_0: MjModel, _1: number): number;
  mj_version(): number;
  mjs_activatePlugin(_0: MjSpec, _1: string): number;
  mjs_delete(_0: MjSpec, _1: MjsElement): number;
  mjs_firstChild(_0: MjsBody, _1: mjtObj, _2: number): MjsElement | undefined;
  mjs_getId(_0: MjsElement): number;
  mjs_getWrap(_0: MjsTendon, _1: number): MjsWrap | undefined;
  mjs_getWrapNum(_0: MjsTendon): number;
  mjs_isWarning(_0: MjSpec): number;
  mjs_nextChild(_0: MjsBody, _1: MjsElement, _2: number): MjsElement | undefined;
  mjs_numWarnings(_0: MjSpec): number;
  mjs_sensorDim(_0: MjsSensor): number;
  mjs_setDeepCopy(_0: MjSpec, _1: number): number;
  mjs_setFrame(_0: MjsElement, _1: MjsFrame): number;
  mjs_setName(_0: MjsElement, _1: string): number;
  mju_bandDiag(_0: number, _1: number, _2: number, _3: number): number;
  mju_isZero(_0: number[], _1: number): number;
  mju_printMat(_0: number[], _1: number, _2: number): void;
  mju_str2Type(_0: string): number;
  mju_threadpool(_0: MjData, _1: number): void;
  mjv_addGeoms(_0: MjModel, _1: MjData, _2: MjvOption, _3: MjvPerturb, _4: number, _5: MjvScene): void;
  mjv_applyPerturbPose(_0: MjModel, _1: MjData, _2: MjvPerturb, _3: number): void;
  mjv_initGeom(_0: MjvGeom, _1: number, _2: number[], _3: number[], _4: number[], _5: number[]): void;
  mjv_updateScene(_0: MjModel, _1: MjData, _2: MjvOption, _3: MjvPerturb, _4: MjvCamera, _5: number, _6: MjvScene): void;
  mj_saveLastXML(_0: string, _1: MjModel): number;
  mj_setLengthRange(_0: MjModel, _1: MjData, _2: number, _3: MjLROpt): number;
  mju_info(_0: number, _1: string): void;
  mjMAXCONPAIR: number;
  mjMAXLIGHT: number;
  mjMAXLINE: number;
  mjMAXLINEPNT: number;
  mjMAXOVERLAY: number;
  mjMAXPLANEGRID: number;
  mjNBIAS: number;
  mjNDYN: number;
  mjNEQDATA: number;
  mjNGAIN: number;
  mjNGROUP: number;
  mjNIMP: number;
  mjNREF: number;
  mjNSOLVER: number;
  mjVERSION_HEADER: number;
  mj_sizeModel(_0: MjModel): bigint;
  mj_getTotalmass(_0: MjModel): number;
  mj_initSensorHistory(_0: MjModel, _1: MjData, _2: number, _3: number[], _4: number[], _5: number): void;
  mj_readCtrl(_0: MjModel, _1: MjData, _2: number, _3: number, _4: number): number;
  mj_setTotalmass(_0: MjModel, _1: number): void;
  mjs_getWrapCoef(_0: MjsWrap): number;
  mjs_getWrapDivisor(_0: MjsWrap): number;
  mjs_makeFlex(_0: MjsBody, _1: string, _2: string|null, _3: number, _4: string|null, _5: number[], _6: number[], _7: number[], _8: number[], _9: number, _10: number, _11: number, _12: number, _13: number, _14: number, _15: number, _16: number[], _17: number[], _18: number[], _19: string|null, _20: MjVFS): MjsFlex | undefined;
  mjs_wrapJoint(_0: MjsTendon, _1: string, _2: number): MjsWrap | undefined;
  mjs_wrapPulley(_0: MjsTendon, _1: number): MjsWrap | undefined;
  mju_Halton(_0: number, _1: number): number;
  mju_L1(_0: number[], _1: number): number;
  mju_clip(_0: number, _1: number, _2: number): number;
  mju_dist3(_0: number[], _1: number[]): number;
  mju_dot(_0: number[], _1: number[]): number;
  mju_dot3(_0: number[], _1: number[]): number;
  mju_isBad(_0: number): number;
  mju_max(_0: number, _1: number): number;
  mju_min(_0: number, _1: number): number;
  mju_mulVecMatVec(_0: number[], _1: number[], _2: number[]): number;
  mju_muscleBias(_0: number, _1: number[], _2: number, _3: number[]): number;
  mju_muscleDynamics(_0: number, _1: number, _2: number[]): number;
  mju_muscleGain(_0: number, _1: number, _2: number[], _3: number, _4: number[]): number;
  mju_norm(_0: number[], _1: number): number;
  mju_norm3(_0: number[]): number;
  mju_round(_0: number): number;
  mju_sigmoid(_0: number): number;
  mju_sign(_0: number): number;
  mju_springDamper(_0: number, _1: number, _2: number, _3: number, _4: number): number;
  mju_sum(_0: number[], _1: number): number;
  mjv_connector(_0: MjvGeom, _1: number, _2: number, _3: number[], _4: number[]): void;
  mjv_frustumHeight(_0: MjvScene): number;
  mjv_moveCamera(_0: MjModel, _1: number, _2: number, _3: number, _4: MjvCamera): void;
  mjv_moveModel(_0: MjModel, _1: number, _2: number, _3: number, _4: number[], _5: MjvScene): void;
  mjv_movePerturb(_0: MjModel, _1: MjData, _2: number, _3: number, _4: number, _5: MjvScene, _6: MjvPerturb): void;
  mjMAXIMP: number;
  mjMAXVAL: number;
  mjMINIMP: number;
  mjMINMU: number;
  mjMINVAL: number;
  mjPI: number;
  mj_actuatorInputName(_0: MjModel, _1: number, _2: number): string;
  mj_id2name(_0: MjModel, _1: number, _2: number): string;
  mj_versionString(): string;
  mjs_getError(_0: MjSpec): string;
  mjs_getName(_0: MjsElement): string;
  mjs_getWarning(_0: MjSpec, _1: number): string;
  mjs_setToAdhesion(_0: MjsActuator, _1: number): string;
  mjs_setToCylinder(_0: MjsActuator, _1: number, _2: number, _3: number, _4: number): string;
  mjs_setToDamper(_0: MjsActuator, _1: number): string;
  mjs_setToMotor(_0: MjsActuator): string;
  mjs_setToVelocity(_0: MjsActuator, _1: number): string;
  mju_type2Str(_0: number): string;
  mju_warningText(_0: number, _1: number): string;
  mju_writeNumBytes(_0: number): string;
  parseXMLString(_0: EmbindString): MjSpec;
  parseXMLString(_0: EmbindString, _1: MjVFS): MjSpec;
  from_xml_string(_0: EmbindString): MjModel;
  from_xml_string(_0: EmbindString, _1: MjVFS): MjModel;
  mj_addM(_0: MjModel, _1: MjData, _2: any, _3: any, _4: any, _5: any): void;
  mj_angmomMat(_0: MjModel, _1: MjData, _2: any, _3: number): void;
  mj_applyFT(_0: MjModel, _1: MjData, _2: number[], _3: number[], _4: number[], _5: number, _6: any): void;
  mj_constraintUpdate(_0: MjModel, _1: MjData, _2: number[], _3: any, _4: number): void;
  mj_contactForce(_0: MjModel, _1: MjData, _2: number, _3: any): void;
  mj_defaultSolRefImp(_0: any, _1: any): void;
  mj_differentiatePos(_0: MjModel, _1: any, _2: number, _3: number[], _4: number[]): void;
  mj_extractState(_0: MjModel, _1: number[], _2: number, _3: any, _4: number): void;
  mj_fullM(_0: MjModel, _1: MjData, _2: any): void;
  mj_geomDistance(_0: MjModel, _1: MjData, _2: number, _3: number, _4: number, _5: any): number;
  mj_getState(_0: MjModel, _1: MjData, _2: any, _3: number): void;
  mj_integratePos(_0: MjModel, _1: any, _2: number[], _3: number): void;
  mj_jac(_0: MjModel, _1: MjData, _2: any, _3: any, _4: number[], _5: number): void;
  mj_jacBody(_0: MjModel, _1: MjData, _2: any, _3: any, _4: number): void;
  mj_jacBodyCom(_0: MjModel, _1: MjData, _2: any, _3: any, _4: number): void;
  mj_jacDot(_0: MjModel, _1: MjData, _2: any, _3: any, _4: number[], _5: number): void;
  mj_jacGeom(_0: MjModel, _1: MjData, _2: any, _3: any, _4: number): void;
  mj_jacPointAxis(_0: MjModel, _1: MjData, _2: any, _3: any, _4: number[], _5: number[], _6: number): void;
  mj_jacSite(_0: MjModel, _1: MjData, _2: any, _3: any, _4: number): void;
  mj_jacSubtreeCom(_0: MjModel, _1: MjData, _2: any, _3: number): void;
  mj_local2Global(_0: MjData, _1: any, _2: any, _3: number[], _4: number[], _5: number, _6: number): void;
  mj_mulJacTVec(_0: MjModel, _1: MjData, _2: any, _3: number[]): void;
  mj_mulJacVec(_0: MjModel, _1: MjData, _2: any, _3: number[]): void;
  mj_mulM(_0: MjModel, _1: MjData, _2: any, _3: number[]): void;
  mj_mulM2(_0: MjModel, _1: MjData, _2: any, _3: number[]): void;
  mj_multiRay(_0: MjModel, _1: MjData, _2: number[], _3: number[], _4: number[], _5: boolean, _6: number, _7: any, _8: any, _9: any, _10: number, _11: number): void;
  mj_normalizeQuat(_0: MjModel, _1: any): void;
  mj_objectAcceleration(_0: MjModel, _1: MjData, _2: number, _3: number, _4: any, _5: number): void;
  mj_objectVelocity(_0: MjModel, _1: MjData, _2: number, _3: number, _4: any, _5: number): void;
  mj_ray(_0: MjModel, _1: MjData, _2: number[], _3: number[], _4: number[], _5: boolean, _6: number, _7: any, _8: any): number;
  mj_rayFlex(_0: MjModel, _1: MjData, _2: number, _3: boolean, _4: boolean, _5: boolean, _6: boolean, _7: number, _8: number[], _9: number[], _10: any, _11: any): number;
  mj_rayHfield(_0: MjModel, _1: MjData, _2: number, _3: number[], _4: number[], _5: any): number;
  mj_rayMesh(_0: MjModel, _1: MjData, _2: number, _3: number[], _4: number[], _5: any): number;
  mj_rne(_0: MjModel, _1: MjData, _2: number, _3: any): void;
  mj_solveM(_0: MjModel, _1: MjData, _2: any, _3: number[]): void;
  mj_solveM2(_0: MjModel, _1: MjData, _2: any, _3: number[], _4: number[]): void;
  mjd_inverseFD(_0: MjModel, _1: MjData, _2: number, _3: boolean, _4: any, _5: any, _6: any, _7: any, _8: any, _9: any, _10: any): void;
  mjd_quatIntegrate(_0: number[], _1: number, _2: any, _3: any, _4: any): void;
  mjd_subQuat(_0: number[], _1: number[], _2: any, _3: any): void;
  mjd_transitionFD(_0: MjModel, _1: MjData, _2: number, _3: boolean, _4: any, _5: any, _6: any, _7: any): void;
  mjs_makeMesh(_0: MjsMesh, _1: mjtMeshBuiltin, _2: any, _3: number): number;
  mjs_resolveOrientation(_0: any, _1: number, _2: string, _3: MjsOrientation): string;
  mjs_setToDCMotor(_0: MjsActuator, _1: any, _2: number, _3: any, _4: any, _5: any, _6: any, _7: any, _8: any, _9: any, _10: number): string;
  mjs_setToIntVelocity(_0: MjsActuator, _1: number, _2: any, _3: any, _4: any, _5: number): string;
  mjs_setToMuscle(_0: MjsActuator, _1: any, _2: number, _3: any, _4: number, _5: number, _6: number, _7: number, _8: number, _9: number, _10: number): string;
  mjs_setToOrientation(_0: MjsActuator, _1: number, _2: any, _3: any, _4: number): string;
  mjs_setToPID(_0: MjsActuator, _1: number, _2: any, _3: any, _4: any, _5: any, _6: any, _7: number, _8: number): string;
  mjs_setToPosition(_0: MjsActuator, _1: number, _2: any, _3: any, _4: any, _5: number): string;
  mju_add(_0: any, _1: number[], _2: number[]): void;
  mju_add3(_0: any, _1: number[], _2: number[]): void;
  mju_addScl(_0: any, _1: number[], _2: number[], _3: number): void;
  mju_addScl3(_0: any, _1: number[], _2: number[], _3: number): void;
  mju_addTo(_0: any, _1: number[]): void;
  mju_addTo3(_0: any, _1: number[]): void;
  mju_addToScl(_0: any, _1: number[], _2: number): void;
  mju_addToScl3(_0: any, _1: number[], _2: number): void;
  mju_axisAngle2Quat(_0: any, _1: number[], _2: number): void;
  mju_band2Dense(_0: any, _1: number[], _2: number, _3: number, _4: number, _5: boolean): void;
  mju_bandMulMatVec(_0: any, _1: number[], _2: number[], _3: number, _4: number, _5: number, _6: number, _7: boolean): void;
  mju_boxQP(_0: any, _1: any, _2: any, _3: number[], _4: number[], _5: number[], _6: number[]): number;
  mju_cholFactor(_0: any, _1: number): number;
  mju_cholFactorBand(_0: any, _1: number, _2: number, _3: number, _4: number, _5: number): number;
  mju_cholSolve(_0: any, _1: number[], _2: number[]): void;
  mju_cholSolveBand(_0: any, _1: number[], _2: number[], _3: number, _4: number, _5: number): void;
  mju_cholUpdate(_0: any, _1: any, _2: number): number;
  mju_copy(_0: any, _1: number[]): void;
  mju_copy3(_0: any, _1: number[]): void;
  mju_copy4(_0: any, _1: number[]): void;
  mju_cross(_0: any, _1: number[], _2: number[]): void;
  mju_d2n(_0: any, _1: number[]): void;
  mju_decodePyramid(_0: any, _1: number[], _2: number[]): void;
  mju_dense2Band(_0: any, _1: number[], _2: number, _3: number, _4: number): void;
  mju_dense2sparse(_0: any, _1: number[], _2: number, _3: number, _4: any, _5: any, _6: any): number;
  mju_derivQuat(_0: any, _1: number[], _2: number[]): void;
  mju_eig3(_0: any, _1: any, _2: any, _3: number[]): number;
  mju_encodePyramid(_0: any, _1: number[], _2: number[]): void;
  mju_euler2Quat(_0: any, _1: number[], _2: string): void;
  mju_eye(_0: any): void;
  mju_f2n(_0: any, _1: number[]): void;
  mju_fill(_0: any, _1: number): void;
  mju_insertionSort(_0: any): void;
  mju_insertionSortInt(_0: any): void;
  mju_mat2Quat(_0: any, _1: number[]): void;
  mju_mat2Rot(_0: any, _1: number[]): number;
  mju_mulMatMat(_0: any, _1: number[], _2: number[], _3: number, _4: number, _5: number): void;
  mju_mulMatMatT(_0: any, _1: number[], _2: number[], _3: number, _4: number, _5: number): void;
  mju_mulMatTMat(_0: any, _1: number[], _2: number[], _3: number, _4: number, _5: number): void;
  mju_mulMatTVec(_0: any, _1: number[], _2: number[], _3: number, _4: number): void;
  mju_mulMatTVec3(_0: any, _1: number[], _2: number[]): void;
  mju_mulMatVec(_0: any, _1: number[], _2: number[], _3: number, _4: number): void;
  mju_mulMatVec3(_0: any, _1: number[], _2: number[]): void;
  mju_mulPose(_0: any, _1: any, _2: number[], _3: number[], _4: number[], _5: number[]): void;
  mju_mulQuat(_0: any, _1: number[], _2: number[]): void;
  mju_mulQuatAxis(_0: any, _1: number[], _2: number[]): void;
  mju_n2d(_0: any, _1: number[]): void;
  mju_n2f(_0: any, _1: number[]): void;
  mju_negPose(_0: any, _1: any, _2: number[], _3: number[]): void;
  mju_negQuat(_0: any, _1: number[]): void;
  mju_normalize(_0: any, _1: number): number;
  mju_normalize3(_0: any): number;
  mju_normalize4(_0: any): number;
  mju_quat2Mat(_0: any, _1: number[]): void;
  mju_quat2Vel(_0: any, _1: number[], _2: number): void;
  mju_quatIntegrate(_0: any, _1: number[], _2: number): void;
  mju_quatZ2Vec(_0: any, _1: number[]): void;
  mju_rayGeom(_0: number[], _1: number[], _2: number[], _3: number[], _4: number[], _5: number, _6: any): number;
  mju_raySkin(_0: number, _1: number, _2: number[], _3: number[], _4: number[], _5: number[], _6: any): number;
  mju_rotVecQuat(_0: any, _1: number[], _2: number[]): void;
  mju_scl(_0: any, _1: number[], _2: number): void;
  mju_scl3(_0: any, _1: number[], _2: number): void;
  mju_sparse2dense(_0: any, _1: number[], _2: number, _3: number, _4: number[], _5: number[], _6: number[]): void;
  mju_sqrMatTD(_0: any, _1: number[], _2: number[], _3: number, _4: number): void;
  mju_standardNormal(_0: any): number;
  mju_sub(_0: any, _1: number[], _2: number[]): void;
  mju_sub3(_0: any, _1: number[], _2: number[]): void;
  mju_subFrom(_0: any, _1: number[]): void;
  mju_subFrom3(_0: any, _1: number[]): void;
  mju_subQuat(_0: any, _1: number[], _2: number[]): void;
  mju_sym2dense(_0: any, _1: number[], _2: number, _3: number[], _4: number[], _5: number[]): void;
  mju_symmetrize(_0: any, _1: number[], _2: number): void;
  mju_transformSpatial(_0: any, _1: number[], _2: number, _3: number[], _4: number[], _5: number[]): void;
  mju_transpose(_0: any, _1: number[], _2: number, _3: number): void;
  mju_trnVecPose(_0: any, _1: number[], _2: number[], _3: number[]): void;
  mju_unit4(_0: any): void;
  mju_zero(_0: any, _1: number): void;
  mju_zero3(_0: any): void;
  mju_zero4(_0: any): void;
  mjv_alignToCamera(_0: any, _1: number[], _2: number[]): void;
  mjv_cameraFrame(_0: any, _1: any, _2: any, _3: any, _4: MjData, _5: MjvCamera): void;
  mjv_cameraFrustum(_0: any, _1: any, _2: any, _3: MjModel, _4: MjvCamera): void;
  mjv_cameraInModel(_0: any, _1: any, _2: any, _3: MjvScene): void;
  mjv_cameraInRoom(_0: any, _1: any, _2: any, _3: MjvScene): void;
  mjv_model2room(_0: any, _1: any, _2: number[], _3: number[], _4: MjvScene): void;
  mjv_room2model(_0: any, _1: any, _2: number[], _3: number[], _4: MjvScene): void;
  mjv_select(_0: MjModel, _1: MjData, _2: MjvOption, _3: number, _4: number, _5: number, _6: MjvScene, _7: any, _8: any, _9: any, _10: any): number;
  mj_saveModel(_0: MjModel, _1: string|null, _2: any): void;
  get_mjDISABLESTRING(): any;
  get_mjENABLESTRING(): any;
  get_mjFRAMESTRING(): any;
  get_mjLABELSTRING(): any;
  get_mjRNDSTRING(): any;
  get_mjTIMERSTRING(): any;
  get_mjVISSTRING(): any;
  mjDISABLESTRING: any;
  mjENABLESTRING: any;
  mjFRAMESTRING: any;
  mjLABELSTRING: any;
  mjRNDSTRING: any;
  mjTIMERSTRING: any;
  mjVISSTRING: any;
}

export type MainModule = WasmModule & typeof RuntimeExports & EmbindModule;
export default function MainModuleFactory (options?: unknown): Promise<MainModule>;
