/** Emscripten module of the minimal MuJoCo build (use through SlimPhysics in slim_physics.ts). */
export interface MujocoSlimModule {
  HEAPU8: Uint8Array; HEAP32: Int32Array; HEAPF32: Float32Array; HEAPF64: Float64Array;
  UTF8ToString(ptr: number): string;
  _malloc(n: number): number; _free(ptr: number): void;
  _slim_load(bytes: number, n: number): number;
  _slim_warning(): number;
  _slim_make_data(model: number): number;
  _slim_step(model: number, data: number): void;
  _slim_forward(model: number, data: number): void;
  _slim_reset_data(model: number, data: number): void;
  _slim_layout(model: number, data: number): number;
  _slim_version(): number;
  _slim_version_string(): number;
}
declare function loadMujocoSlim(options?: { locateFile?: (path: string, prefix: string) => string; [k: string]: unknown }): Promise<MujocoSlimModule>;
export default loadMujocoSlim;
