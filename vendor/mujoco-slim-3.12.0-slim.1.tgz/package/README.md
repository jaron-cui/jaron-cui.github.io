# mujoco-slim 3.12.0

A minimal MuJoCo 3.12.0 WebAssembly module, built from the same libmujoco.a as the optimized
@mujoco/mujoco 3.12.0 package (-O3, SIMD). Physics results are bit-identical to that package.

It exports only: load an .mjb from bytes, mj_makeData, mj_step, mj_forward, mj_resetData, the
version, and a layout table of every mjModel/mjData array. JavaScript reads those arrays as
typed-array views. Use it through `SlimPhysics` (slim_physics.ts).

Not included: the XML parser, the model compiler (MjSpec), mesh/texture decoders, plugins, the
filesystem, and the embind bindings. Requires WebAssembly SIMD. Built by slim.c + build.sh.

This is an unofficial build, not published by the MuJoCo authors. MuJoCo is Apache-2.0.
